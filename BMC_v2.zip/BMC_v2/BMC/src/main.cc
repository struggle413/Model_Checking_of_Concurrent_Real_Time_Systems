#include <gmp.h>
extern "C"
{
#include "mathsat.h"
} 
#include <iostream>
#include <fstream>
#include "driver.h"
#include "Network.h"

#include <list>


int main(int argc, char *argv[])
{
    autoNetwork net;
    example::Driver driver(net);
    bool readfile = false;

    for(int ai = 1; ai < argc; ++ai)
    {
	if (argv[ai] == std::string ("-p")) {
	    driver.trace_parsing = true;
	}
	else if (argv[ai] == std::string ("-s")) {
	    driver.trace_scanning = true;
	}
	else
	{
	    // read a file with expressions

	    std::fstream infile(argv[ai]);
	    if (!infile.good())
	    {
		std::cerr << "Could not open file: " << argv[ai] << std::endl;
		return 0;
	    }

	    
	    bool result = driver.parse_stream(infile, argv[ai]);
	    if (result)
	    {

               cout << "  ***********************************************************************\n"
                    << "  *  Lazy predicate abstract for reachability of timed automata.  *\n" 
                    << "  *             If needed, contact chenzuxi814@hotmail.com.             *\n" 
                    << "  *---------------------------------------------------------------------*\n"
                    << "  *         there is no exist counterexample for timed automata         *\n"     
                    << "  ***********************************************************************\n" << endl;

                  net.init();
                  net.encTrans(1);
                  net.encInit();
                  net.encPropFormula(net.autoProp,2);
                 net.encLastGlobalInv(2);

                //net.displayTransition();
                //net.displayParameter2Value();
              //  net.displayActiveTrans(net.initGlobalState);

               // ARTree tree(net);
               // tree.Unwind();

				
	    }

	    readfile = true;
	}
    }

    if (readfile) return 0;
    
    std::cout << "Reading expressions from stdin" << std::endl;

}
