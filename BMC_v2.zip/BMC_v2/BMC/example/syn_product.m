MODULE Process Product1()
{
    VAR 
        Location : {l0, l1,l2}
        Action : {a,b}
        Init:{l0}
        Clock: {x,y} 
    INVS
        l0 : {x <= 10}
    TRANS
        {FROM l0; ACTION {a}; CLOCK_RESET x; GOTO l1}
        {FROM l0; ACTION {b}; CLOCK_GUARD x = 1 ;  GOTO l2}

}
MODULE Process Product2()
{
    VAR 
        Location : {r0, r1}
        Action : {a,c}
        Init:{r0}
        Clock: {z,y} 
    INVS
        r0 : {y <= 10}
    TRANS
        {FROM r0; ACTION {a}; CLOCK_GUARD not(z - y < 4 and y >=2) ; GOTO r1}
        {FROM r0; ACTION {c}; GOTO r2}

}
NETSYSTEMS
{

    PRO
    p1:Product1();
    p2:Product2();

    INVARSPEC  (p1.l2) and (p2.r2) 
}

