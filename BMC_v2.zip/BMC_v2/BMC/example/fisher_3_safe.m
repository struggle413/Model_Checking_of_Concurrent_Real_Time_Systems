MODULE Process Fischer(pid,id,k,d)
{
    VAR 
        Location : {ideal,req, wait, cs}
        Init:{ideal}
        Clock: {x} 
    INVS

    TRANS
        {FROM ideal;                  VAR_GUARD id = 0 ;   CLOCK_RESET x;                           GOTO req}
        {FROM ideal;                  VAR_GUARD id = 0 ;   CLOCK_RESET x;                           GOTO cs}
        {FROM req;                                         CLOCK_RESET x; VAR_ASSIGNMENT id := pid; GOTO wait}
        {FROM wait; CLOCK_GUARD x>k;  VAR_GUARD id = 3 ;                                           GOTO ideal}
        {FROM wait; CLOCK_GUARD x>k;  VAR_GUARD id = 3 ;                                           GOTO cs}
        {FROM cs;                                                         VAR_ASSIGNMENT id := 0;   GOTO ideal}

}

NETSYSTEMS
{
    VAR 
    id 0...2;
    PRO
    p1:Fischer(1,id,5,8);
    p2:Fischer(2,id,5,8);

    INVARSPEC (p1.cs and p2.cs)
 }

