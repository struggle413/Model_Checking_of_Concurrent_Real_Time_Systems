MODULE Process Fischer(pid,id,k,d)
{
    VAR 
        Location : {ideal,req, wait, cs}
        Init:{ideal}
        Clock: {x} 
    INVS
        req : {x <= d}
    TRANS
        {FROM ideal;  GUARD id = 0 ; RESET x := 0; GOTO req}
        {FROM req; RESET x := 0, id := pid;  GOTO wait}
        {FROM wait;  GUARD ((not(id = pid)) and x >= k) ; GOTO ideal}
        {FROM wait;  GUARD id = pid and x >= k ; GOTO cs}
        {FROM cs; RESET x := 0, id := 0;  GOTO ideal}

}

NETSYSTEMS
{
    VAR 
    id 0...24;
    PRO
    p1:Fischer(1,id,5,7);
    p2:Fischer(2,id,5,7);
    p3:Fischer(3,id,5,7);
    p4:Fischer(4,id,5,7);
    p5:Fischer(5,id,5,7);
    p6:Fischer(6,id,5,7);
    p7:Fischer(7,id,5,7);
    p8:Fischer(8,id,5,7);
    p9:Fischer(9,id,5,7);
    p10:Fischer(10,id,5,7);
    p11:Fischer(11,id,5,7);
    p12:Fischer(12,id,5,7);

    p13:Fischer(13,id,5,7);
    p14:Fischer(14,id,5,7);
    p15:Fischer(15,id,5,7);
    p16:Fischer(16,id,5,7);
    p17:Fischer(17,id,5,7);
    p18:Fischer(18,id,5,7);

    p19:Fischer(19,id,5,7);
    p20:Fischer(20,id,5,7);
    p21:Fischer(21,id,5,7);
    p22:Fischer(22,id,5,7);
    p23:Fischer(23,id,5,7);
    p24:Fischer(24,id,5,7);

    p25:Fischer(25,id,5,7);
    p26:Fischer(26,id,5,7);
    p27:Fischer(27,id,5,7);
    p28:Fischer(28,id,5,7);

    p29:Fischer(29,id,5,7);
    p30:Fischer(30,id,5,7);
    p31:Fischer(31,id,5,7);
    p32:Fischer(32,id,5,7);
    p33:Fischer(33,id,5,7);
    p34:Fischer(34,id,5,7);

    p35:Fischer(35,id,5,7);
    p36:Fischer(36,id,5,7);
    p37:Fischer(37,id,5,7);
    p38:Fischer(38,id,5,7);

    p39:Fischer(39,id,5,7);
    p40:Fischer(40,id,5,7);
    p41:Fischer(41,id,5,7);
    p42:Fischer(42,id,5,7);
    p43:Fischer(43,id,5,7);
    p44:Fischer(44,id,5,7);
    p45:Fischer(45,id,5,7);
    p46:Fischer(46,id,5,7);
    p47:Fischer(47,id,5,7);
    p48:Fischer(48,id,5,7);

    p49:Fischer(49,id,5,7);
    p50:Fischer(50,id,5,7);

    INVARSPEC (p1.cs and p2.cs)  or (p1.cs and p3.cs) or (p1.cs and p4.cs) or (p1.cs and p5.cs)  or (p1.cs and p6.cs) or (p1.cs and p7.cs) or (p1.cs and p8.cs)  or (p1.cs and p9.cs) or (p1.cs and p10.cs) or (p1.cs and p11.cs)  or (p1.cs and p12.cs) or (p1.cs and p13.cs)
 }

