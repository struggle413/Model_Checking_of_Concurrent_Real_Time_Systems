MODULE Process root()
{
    VAR 
        Location : {send,wait,done}
        Init:{send}

    TRANS
        {FROM send; GLOBAL_RESET x1,x2; VAR_ASSIGNMENT id1:=1, id2:=1; GOTO wait}
        {FROM wait; VAR_GUARD id1=0 and id2=0; GLOBAL_GUARD x1 >= 5 and x2 >= 6 and x0<=14; GOTO done}
}




NETSYSTEMS
{
    VAR 
    id1 0...1;
    id2 0...1;
    CLOCK:{x0,x1,x2}
    BOOLEAN:{id1,id2}
    
    PRO
    p0:root();

  
    INVARSPEC (p0.done)
 }

