#ifndef AUTOMATON_H
#define AUTOMATON_H
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <math.h>
#include <map>  
#include "Network.h"
#include <iostream>
using namespace std;

class AutomatonCal
{
public:

    autoProc_Param* procParam;
    shared_Vars*  sharedVars;
    shared_Bools* sharedBools;
    shared_Clocks* sharedClocks;
    std::map<autoProc_Body* , autoTemp_Body*> mapProc2Autotemp;
    autoTemp_Body* autoTemp;  // automata template
    std::map<std::string, int> location2int;
    std::string procname;
    int bitsNo;
    int location_num;
    //explicit autoNetwork();
    explicit AutomatonCal(std::map<autoProc_Body* , autoTemp_Body*> _Proc2Autotemp, std::string _procname, shared_Vars* _varname, shared_Bools* _boolname, shared_Clocks* _clockname, autoProc_Param* _params, autoTemp_Body* _autoTemp)
	: mapProc2Autotemp(_Proc2Autotemp), procname(_procname),sharedBools(_boolname),sharedVars(_varname),sharedClocks(_clockname), procParam(_params), autoTemp(_autoTemp)
    {
         autoTemp_Locat* locats = this->autoTemp->templocats;
         if(locats != NULL)
         while(locats->previous != NULL)
            locats = locats ->previous;
         location_num = 0;
         while(locats != NULL)
         {
            location2int[locats->locatname] = location_num;
            location_num = location_num + 1;
            locats = locats -> next; 
         }
         bitsNo = ceil(log2(location_num));
    }

    ~AutomatonCal();

    std::string  encTrans(int k);
    std::string  encDiscTran(autoTemp_Trans* tran, int k);
    std::string  encExpr(autoTemp_Expr* expr, int k);
    std::string  encSharedVarExpr(autoTemp_Expr* expr, int k, std::set<std::string> &compare_vars);
    std::string  encSharedClockExpr(autoTemp_Expr* expr, int k, std::set<std::string> &compare_vars);

    std::string  encStutTran(int k);
    std::string  encLocationInv(std::string location_name, int k, std::set<std::string> &compare_vars);

    std::string  encGlobalReset(autoTemp_GlobalReset* reset, int k);
    std::string  encLocalReset(autoTemp_LocalReset* reset, int k);
    std::string  encVarReset(autoTemp_Assignment* reset, int k);
    std::string  encLocalClockGuard(autoTemp_Expr* guard ,int k);
    std::string  encGlobalClockGuard(std::string location_name, autoTemp_Expr* guard ,int k);
    std::string  encVarsGuard(autoTemp_Expr* guard ,int k);
    std::string  encGlobalInv(std::string clock,int k);
    std::string  encLocation(std::string name,int k);
    std::string  encClockrange(int k);
    std::string  encLocationEqual(int k);
    vector<bool> int2binvect(int number, int usedBits);

};

#endif
