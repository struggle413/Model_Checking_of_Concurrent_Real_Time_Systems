#include "Network.h"
#include <iostream>
#include <sstream>
#include <vector>
#include <set>
#include <map>
#include "Automaton.h"

using namespace std;
void autoNetwork::init()
{
	 autoProc_Body* Procs= this->autoProcs;
	 while((*Procs).previous!=NULL)	 
		 Procs = (*Procs).previous;
     while(Procs != NULL)
     {
		 //autoTemp_Body*  currTemp = serachAutoTemp(Procs->tempname);
		 this->mapProc2Autotemp[Procs] = serachAutoTemp(Procs->tempname);
		 //new AutomatonCal(Procs->autoname,this->sharedVars,this->sharedClocks,this->sharedBools,Procs->params,currTemp);;
		 Procs = Procs->next;
	 }
	 
}
std::string autoNetwork::encInit()
{
	std::string strInit = "";
	std::string strInitClock = "";
	std::string strInitLocat = "";
    for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
    {
	    AutomatonCal* autom = new AutomatonCal(this->mapProc2Autotemp,(*it).first->autoname,this->sharedVars,this->sharedBools,this->sharedClocks,(*it).first->params,(*it).second);
        autoTemp_Init* currAutoInits = (*it).second->tempinits;
        
     	while(currAutoInits->previous != NULL)  //ensure return to the begin of init list;
	        currAutoInits = (*currAutoInits).previous;
	    std::string currAutoInitstr = "";
	    int counter = 0;
	    while(currAutoInits!=NULL)
	    {
           currAutoInitstr = currAutoInitstr + " " + autom->encLocation(currAutoInits->initname, 0);
           currAutoInits = currAutoInits->next;
           counter = counter + 1;
		}
        if(counter > 1)
          currAutoInitstr = "( or " + currAutoInitstr + ")";
        strInitLocat =  strInitLocat + " " + currAutoInitstr;
        
        autoTemp_Clock* currAutoClocks = (*it).second->tempclocks;
        if(currAutoClocks!=NULL)
	    while(currAutoClocks->previous != NULL)  //ensure return to the begin of clock list;
	       currAutoClocks = (*currAutoClocks).previous;
	    std::string currAutoClockStr =  "( >= "  + (*it).first->autoname + "_gtime_0  0)";
		while(currAutoClocks != NULL)
		{
		   currAutoClockStr = currAutoClockStr + " ( = " + (*it).first->autoname + "_" + currAutoClocks->clockname + "_0  0)";
		   currAutoClocks = currAutoClocks->next;
	    }
	    strInitClock = strInitClock + " " +currAutoClockStr;
	}
    
    std::string init_var="";
    shared_Vars* sharedvar = this->sharedVars;
    if(sharedvar != NULL)
    {
        while(sharedvar->previous != NULL)  
	       sharedvar = (*sharedvar).previous; 
	    while(sharedvar != NULL)
	    {
	       init_var = init_var + " ( = rtime_" + sharedvar->paramname + "_0 0) ( = wtime_" + sharedvar->paramname + "_0 0) ( = " + sharedvar->paramname + "_0 0)";
           sharedvar=sharedvar->next;
	    }
	 }
	 
    std::string init_bool="";
    shared_Bools* sharedbool = this->sharedBools;
    if(sharedbool != NULL)
    {
        while(sharedbool->previous != NULL)  
	       sharedbool = (*sharedbool).previous; 
	    while(sharedbool != NULL)
	    {
	       init_bool = init_bool + " ( = rtime_" + sharedbool->paramname + "_0 false) ( = wtime_" + sharedbool->paramname + "_0 false) ( = " + sharedbool->paramname + "_0 false)";
           sharedbool = sharedbool->next;
	    }
	 }

    std::string init_clock="";
    shared_Clocks* sharedclock = this->sharedClocks;

    if(sharedclock != NULL)
    {
        while(sharedclock->previous != NULL)  
	       sharedclock = (*sharedclock).previous; 
	    while(sharedclock != NULL)
	    {
	       init_clock = init_clock + " ( = rtime_" + sharedclock->paramname + "_0 0) ( = " + sharedclock->paramname + "_0 0) ( = " + sharedclock->paramname + "_0 0)";
           sharedclock=sharedclock->next;
	    }
	 }
	 //std::cout << "Expression for Initial formula:" <<"( and "+ strInitLocat + " " + strInitClock  + " " + init_var + " " + init_bool  + " " +  init_clock + " )"<< std::endl;

	return "( and "+ strInitLocat + " " + strInitClock  + " " + init_var + " " + init_bool  + " " +  init_clock + ")";
}

std::string autoNetwork::encTrans(int k)
{
	std::string strTrans = "";
    for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
    {
		AutomatonCal* autom = new AutomatonCal(this->mapProc2Autotemp, (*it).first->autoname,this->sharedVars,this->sharedBools,this->sharedClocks,(*it).first->params,(*it).second);
     	strTrans = strTrans + " " + autom->encTrans(k) ;
	}
	return  "( and " + encActionSyn(k) + " " + encSharedVarSyn(k)  + " " + encSharedBoolSyn(k) + " " + encSharedClockSyn(k) + " " + strTrans +")";
}
std::string autoNetwork::encActionSyn(int k)
{
    stringstream k1str;
    k1str<<k-1;
    std::string channal_syn_str = "";
    std::set<std::string> actionlist = this->actionlist;
    set<std::string>::reverse_iterator rit;
    for(rit=actionlist.rbegin();rit!=actionlist.rend();rit++)
    {
	   std::string action_syn_str = "";

       int counter_action=0;
       for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
       {
		   std::string first_autoPro = "";
		   autoTemp_Action* actions = (*it).second->tempactions;
           if(actions != NULL)
           {
   		        while(actions->previous != NULL)  //ensure return to the begin of init list;
	    	       actions = (*actions).previous;
      	        while(actions != NULL)
     	 	    {
        	       if(*rit==actions->actionName)
        	       {
        	       	     if(counter_action==0)
        	       	     {
        	       	     	 first_autoPro = (*it).first->autoname;
        	       	     }
        	       	     else
        	       	     {
        	       	     	 action_syn_str = action_syn_str + " ( = " + first_autoPro + "_gtime_" +k1str.str() +" " + (*it).first->autoname + "_gtime_" +k1str.str() + ")";
        	       	     }
        	       	     counter_action = counter_action + 1;
        	       	     break;
        	       }
                   actions = actions->next;
        	    }
	       }
       }
       if(action_syn_str!="")
	   {
	      channal_syn_str = channal_syn_str + " ( or ( not " + *rit + "_" + k1str.str() + ") ( and " + action_syn_str + "))";
	   }
   }
   return channal_syn_str;
}

std::string autoNetwork::encSharedVarSyn(int k)
{
    shared_Vars*  sharedvars = this->sharedVars;
    std::string range_str = "";
    std::string timeinc_str = "";
    std::string nochange_str = "";
    stringstream k1str;
    stringstream k2str;
    k1str<<k-1;
    k2str<<k;
    
    if(sharedvars != NULL)
    {
        while(sharedvars->previous != NULL)  
           sharedvars = (*sharedvars).previous; 
    }
    while(sharedvars != NULL)
    {
		if(k==1)
		   range_str = range_str + " ( <= " + sharedvars->paramname + "_" + k1str.str() + " " +sharedvars->ubounded +") ( >= " + sharedvars->paramname + "_" + k1str.str() + " " +sharedvars->lbounded + ")";
        range_str = range_str + " ( <= " + sharedvars->paramname + "_" + k2str.str() + " " +sharedvars->ubounded +") ( >= " + sharedvars->paramname + "_" + k2str.str() + " " +sharedvars->lbounded + ")";
		
		timeinc_str = timeinc_str + " ( >= " + "wtime_" + sharedvars->paramname + "_" + k2str.str() + "  wtime_"  + sharedvars->paramname + "_" +  k1str.str() + ")";
	    timeinc_str = timeinc_str + " ( >= " + "rtime_" + sharedvars->paramname + "_" + k2str.str() + "  rtime_"  + sharedvars->paramname + "_" +  k1str.str() + ")";

        autoProc_Body* Procs = this->autoProcs; 
        while(Procs->previous != NULL)  
           Procs = (*Procs).previous; 
        std::string noProcschange_str = "";
        while(Procs != NULL)
        {
			noProcschange_str = noProcschange_str + " " + Procs->autoname  + "_" + sharedvars->paramname + "_w_" + k1str.str() + " ";
			Procs = Procs->next;
		}
        nochange_str = nochange_str + " ( or " + noProcschange_str + " ( = " + sharedvars->paramname + "_" +  k2str.str() + " " +  sharedvars->paramname + "_" +  k1str.str() +  "))";
           
		sharedvars = sharedvars->next;
	}
	
    return "( and " + range_str + " " + timeinc_str + " " + nochange_str +")";
}
std::string autoNetwork::encSharedBoolSyn(int k)
{
	
    shared_Bools*  sharedbools = this->sharedBools;
    std::string timeinc_str = "";
    std::string nochange_str = "";
    stringstream k1str;
    stringstream k2str;
    k1str<<k-1;
    k2str<<k;
    
    if(sharedbools != NULL)
    {
        while(sharedbools->previous != NULL)  
           sharedbools = (*sharedbools).previous; 
    }
    while(sharedbools != NULL)
    {

		timeinc_str = timeinc_str + " ( >= " + "wtime_" + sharedbools->paramname + "_" + k2str.str() + "  wtime_"  + sharedbools->paramname + "_" +  k1str.str() + ")";
	    timeinc_str = timeinc_str + " ( >= " + "rtime_" + sharedbools->paramname + "_" + k2str.str() + "  rtime_"  + sharedbools->paramname + "_" +  k1str.str() + ")";

        autoProc_Body* Procs = this->autoProcs; 
        while(Procs->previous != NULL)  
           Procs = (*Procs).previous; 
        std::string noProcschange_str = "";
        while(Procs != NULL)
        {
			noProcschange_str = noProcschange_str + " " + Procs->autoname  + "_" + sharedbools->paramname + "_w_" + k1str.str() + " ";
			Procs = Procs->next;
		}
        nochange_str = nochange_str + " ( or " + noProcschange_str + " ( = " + sharedbools->paramname + "_" +  k2str.str() + " " +  sharedbools->paramname + "_" +  k1str.str() +  "))";
           
		sharedbools = sharedbools->next;
	}
	
    return "( and " + timeinc_str + " " + nochange_str +")";
}

std::string autoNetwork::encSharedClockSyn(int k)
{
    shared_Clocks*  sharedclocks = this->sharedClocks;
    std::string timeinc_str = "";
    std::string nochange_str = "";
    stringstream k1str;
    stringstream k2str;
    k1str<<k-1;
    k2str<<k;
    
    if(sharedclocks != NULL)
    {
        while(sharedclocks->previous != NULL)  
           sharedclocks = (*sharedclocks).previous; 
    }
    while(sharedclocks != NULL)
    {
	    timeinc_str = timeinc_str + " ( >= " + "rtime_" + sharedclocks->paramname + "_" + k2str.str() + "  rtime_"  + sharedclocks->paramname + "_" +  k1str.str() + ")";

        autoProc_Body* Procs = this->autoProcs; 
        while(Procs->previous != NULL)  
           Procs = (*Procs).previous; 
        std::string noProcschange_str = "";
        while(Procs != NULL)
        {
			noProcschange_str = noProcschange_str + " " + Procs->autoname  + "_" + sharedclocks->paramname + "_w_" + k1str.str() + " ";
			Procs = Procs->next;
		}
        nochange_str = nochange_str + " ( or " + noProcschange_str + " ( = " + sharedclocks->paramname + "_" +  k2str.str() + " " +  sharedclocks->paramname + "_" +  k1str.str() +  "))";          
		sharedclocks = sharedclocks->next;
	}
    return "( and " + timeinc_str + " " + nochange_str +")";
}

autoTemp_Body* autoNetwork::serachAutoTemp(string tempName)
{
	autoTemp_Body* tempAutoTemps = this->autoTemps;
	while(tempAutoTemps->previous != NULL)  //ensure return to the begin of template list;
	    tempAutoTemps = (*tempAutoTemps).previous;   
	while(tempAutoTemps!= NULL)
	{
		if(tempAutoTemps->tempname == tempName)
		{
			return tempAutoTemps;
		}
	    tempAutoTemps = tempAutoTemps->next;
	}
}

std::string autoNetwork::encPropFormula(autoProp_Expr* expr, int k)
{
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string strproperty="";
     
     if(expr == NULL)
     return "";
     if(expr->nodetype == 2 ) //constant
     {
          strproperty = strproperty + expr->content;
     }  

     if(expr->nodetype == 1 ) //variable
     {
        for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
        {
			 if(expr->process == (*it).first->autoname)
			 {
	              bool flag = true;
                  autoTemp_Clock* clocks = (*it).second->tempclocks;
                  if(clocks!=NULL)
        	        while(clocks->previous != NULL)  //ensure return to the begin of init list;
	                   clocks = (*clocks).previous;
                  while((clocks != NULL) && flag)
                  {
                      if(expr->content == clocks->clockname)
                      {
                          strproperty = strproperty + expr->process + "_" + expr->content + "_" + k2str.str();
                          flag = false;
                      }
                      clocks = clocks->next;
                  }
                  
                   autoTemp_Locat* locations = (*it).second->templocats;
        	       while(locations->previous != NULL)  //ensure return to the begin of init list;
	                  locations = (*locations).previous;
                   while((locations != NULL) && flag)
                   {
                       if(expr->content == locations->locatname)
                       {
	                        AutomatonCal* autom = new AutomatonCal(this->mapProc2Autotemp,(*it).first->autoname,this->sharedVars,this->sharedBools,this->sharedClocks,(*it).first->params,(*it).second);
                            strproperty = strproperty + " ( and " + autom->encLocation(locations->locatname, k) + ")";
                            flag = false;
                       }
                      locations = locations->next;
                   }
			   }
	      }
		
     } 
     if(expr->nodetype == 4 ) //minus
     {
          strproperty = strproperty + "( " + expr->content + " " +  encPropFormula(expr->right, k)  + " " + encPropFormula(expr->left, k) + " )";
     }
     if(expr->nodetype == 5 ) //only one variable term
     {
          strproperty = strproperty + "(" +  expr->process +  "_gtime_" + k2str.str() + " - " +  expr->process + "_" + expr->content + "_" + k2str.str() + ")";
     }
 
     if(expr->nodetype == 0 ) //operator
     {
          strproperty = strproperty + "( " +  expr->content + " " +   encPropFormula(expr->left, k)  + " " + encPropFormula(expr->right, k) + ")";
     }
     if(expr->nodetype == 3 ) //operator
     {
          strproperty = strproperty + "(" +  expr->content + " " + encPropFormula(expr->right, k) + ")";
     }

     std::cout << "Reading Property expressions roperty formula:" << strproperty << std::endl;

     return strproperty;
}
std::string  autoNetwork::encTimesyn(int k)
{
     stringstream k2str;
     k2str<<k;
     
     std::string time_syn = "";
     autoProc_Body*  autoProc = this-> autoProcs;
     while(autoProc->previous != NULL)  //ensure return to the begin of template list;
	    autoProc = (*autoProc).previous;   
     std::string fristProcname = autoProc->autoname;
     while(autoProc != NULL)
     {
          if(autoProc->autoname!= fristProcname)
             time_syn = time_syn + " ( = " + fristProcname + "_gtime_"+ k2str.str() + " " + autoProc->autoname  + "_gtime_"+ k2str.str() + ")";
          autoProc = autoProc->next;     
     }
     return time_syn;
     std::cout << "Reading Property expressions roperty formula2:" << time_syn << std::endl;

}
std::string  autoNetwork::encLastGlobalInv(int k)
{
    stringstream k2str;
     k2str<<k;
     std::string strLastGlobalInv="";

    for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
    {
		autoTemp_Locat2inv* loc2invs = (*it).second->temploc2invs;
		std::string proc_name = (*it).first->autoname;
		if(loc2invs!=NULL)
		  while(loc2invs->previous)
		     loc2invs = loc2invs->previous;
		 while(loc2invs!=NULL)
		 {
	         AutomatonCal* autom = new AutomatonCal(this->mapProc2Autotemp,(*it).first->autoname,this->sharedVars,this->sharedBools,this->sharedClocks,(*it).first->params,(*it).second);
             std::string strLastGlobalInvExpr ="";
             autoTemp_InvarExpr* InvExpr = loc2invs->invariant;
		     if(InvExpr!=NULL)
		     while(InvExpr->previous!=NULL)
		        InvExpr = (*InvExpr).previous;
		     while(InvExpr!=NULL)
		     {	
				bool Isone = false;
				if(strLastGlobalInvExpr == "")	
				{	 
			       strLastGlobalInvExpr = " ( " + InvExpr->oper + " ( - " +  proc_name + "_time" + "_" + k2str.str() + " " + InvExpr->left_content  + "_" + k2str.str() + ") " + InvExpr->right_content + ")";
		        }
		        else
		        {
		          strLastGlobalInvExpr =  strLastGlobalInvExpr + " ( "  + InvExpr->oper + " ( - " +  proc_name + "_time" + "_" + k2str.str() + " " + InvExpr->left_content  + "_" + k2str.str() + ") " + InvExpr->right_content + ")";
			      Isone =true;
			    }
			    if(Isone==true)
			       strLastGlobalInvExpr = " ( and " +strLastGlobalInvExpr + ")";
                InvExpr = InvExpr->next;
           	 }
		     strLastGlobalInv = strLastGlobalInv + " ( or ( not ( and " +  autom->encLocation(loc2invs->locatname, k) + ")) " + strLastGlobalInvExpr + ")";
		     loc2invs = loc2invs->next;
		 }
	}
	
	std::cout<<"last states Global Invariant:"<<strLastGlobalInv<<std::endl;
	return strLastGlobalInv;
}

std::string delcareVars(int k)
{
	stringstream ss;
	ss<<"(set-loigc "<< "QF_RDL"<<")"<<std::endl;
	ss<<"(set-loigc "<< "QF_IDL"<<")"<<std::endl;

	shared_Vars* sharedIntVars= this->sharedVars;
	if(sharedIntVars!=NULL)
	  while(sharedIntVars->previous!=NULL)
	    sharedIntVars = sharedIntVars -> previous;
	while(sharedIntVars!=NULL)
	{
		ss<<"declare-fun "<< sharedIntVars->paramname <<"_"<< k << " () Real)"<<std::endl;
		ss<<"(assert ( >= " << sharedIntVars->paramname << "_" << k " " << sharedIntVars->lbounded <<") )"<<std::endl;
		ss<<"(assert ( <= " << sharedIntVars->paramname << "_" << k " " << sharedIntVars->ubounded <<") )"<<std::endl;
		sharedIntVars = sharedIntVars -> next;
	}

	shared_Bools* sharedBoolVars= this->sharedBools;
	if(sharedBoolVars!=NULL)
	  while(sharedBoolVars->previous!=NULL)
	    sharedBoolVars = sharedBoolVars -> previous;
	while(sharedBoolVars!=NULL)
	{
		ss<<"declare-fun "<< sharedBoolVars->paramname <<"_"<< k << " () Bool)"<<std::endl;
		sharedBoolVars = sharedBoolVars -> next;
	}
	

	shared_Clocks* sharedClockVars= this->sharedClocks;
	if(sharedClockVars!=NULL)
	  while(sharedClockVars->previous!=NULL)
	    sharedClockVars = sharedClockVars -> previous;
	while(sharedClockVars!=NULL)
	{
		ss<< "declare-fun " << sharedClockVars->paramname << "_" << k << " () Real)"<<std::endl;
		sharedClockVars = sharedClockVars -> next;
	}
	
	templocats
	
    for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
    {
	    AutomatonCal* autom = new AutomatonCal(this->mapProc2Autotemp,(*it).first->autoname,this->sharedVars,this->sharedBools,this->sharedClocks,(*it).first->params,(*it).second);
        autoTemp_Locat* currAutoLocations = (*it).second->templocats;
        if(currAutoLocations!=NULL)
           while(currAutoLocations->previous)
             currAutoLocations = currAutoLocations->previous;
             
        while(currAutoLocations!=NULL)
        {
		    ss<< "declare-fun " << autom->encLocation(currAutoLocations->locatname,k) << " () Bool)"<<std::endl;
            currAutoLocations = currAutoLocations -> next;           
		}
		
		
		autoTemp_Action* action = (*it).second->tempactions;
        if(action!=NULL)
           while(action->previous)
             action = action->previous;
        while(action!=NULL)
        {
		    ss<< "declare-fun " << action-> actionName << " () Bool)"<<std::endl;
            currAutoLocations = currAutoLocations -> next; 
		}
		
		autoTemp_Clock* localclocks = (*it).second-> tempclocks
        if(localclocks!=NULL)
           while(localclocks->previous)
             localclocks = localclocks->previous;
        while(localclocks!=NULL)
        {
		    ss<< "declare-fun " << localclocks-> clockname << " () Real)"<<std::endl;
            localclocks = localclocks -> next; 
		}
	}	
}
