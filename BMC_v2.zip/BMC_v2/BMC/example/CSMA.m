MODULE Process Medium(d)
{
    VAR 
        Location : {init, transm,collision}
        Action : {cd, bgein1, begin2, end1, end2, busy1, busy2}
        Init:{init}
        Clock: {x} 
    INVS
        collision : {x <= d}
    TRANS
        {FROM init; ACTION {begin1, begin2}; RESET x := 0 ; GOTO transm}
        {FROM transm; ACTION {end1, end2}; RESET x := 0 ; GOTO init}
        {FROM transm; ACTION {busy1, busy2}; GUARD x >= d ; GOTO transm}
        {FROM transm; ACTION {begin1, begin2}; GUARD x < d ;RESET x := 0 ; GOTO collision}
        {FROM collision; ACTION {cd}; GUARD x <= d ;RESET x := 0 ; GOTO init}

}
MODULE Process sender1(d, del)
{
    VAR 
        Location : {init, transm,collision,send}
        Action : {cd, bgein1, end1, busy1}
        Init:{init}
        Clock: {x} 
    INVS
        collision : {x <= d}
        transm : {x <= del}
        send : {x = 0}


    TRANS
        {FROM init; ACTION {cd}; GOTO init}
        {FROM init;  RESET x := 0 ; GOTO send}
        {FROM send; ACTION {begin1}; RESET x := 0 ; GOTO transm}
        {FROM send; ACTION {cd, busy1}; RESET x := 0 ; GOTO collision}
        {FROM collision; RESET x := 0 ; GOTO send}
        {FROM collision;  ACTION {cd} ; GOTO collision}
        {FROM transm; ACTION {cd}; RESET x := 0 ; GOTO collision}
        {FROM transm; ACTION {end1}; GUARD x = del RESET x := 0 ; GOTO init}

}
MODULE Process sender1(d, del)
{
    VAR 
        Location : {init, transm,collision,send}
        Action : {cd, bgein2, end2, busy2}
        Init:{init}
        Clock: {x} 
    INVS
        collision : {x <= d}
        transm : {x <= del}
        send : {x = 0}


    TRANS
        {FROM init; ACTION {cd}; GOTO init}
        {FROM init;  RESET x := 0 ; GOTO send}
        {FROM send; ACTION {begin2}; RESET x := 0 ; GOTO transm}
        {FROM send; ACTION {cd, busy2}; RESET x := 0 ; GOTO collision}
        {FROM collision; RESET x := 0 ; GOTO send}
        {FROM collision;  ACTION {cd} ; GOTO collision}
        {FROM transm; ACTION {cd}; RESET x := 0 ; GOTO collision}
        {FROM transm; ACTION {end2}; GUARD x = del RESET x := 0 ; GOTO init}

}
NETSYSTEMS
{

    PRO
    server:Medium(20);
    sender1:sender1(40, 5);
    sender2:sender2(40, 5);

    INVARSPEC  sender1.transm  and sender1.transm 
}

