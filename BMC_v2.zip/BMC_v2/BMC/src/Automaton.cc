#include "Automaton.h"
#include "Network.h"
#include <sstream>
#include <iostream>
using namespace std;

vector<bool> AutomatonCal::int2binvect(int number, int usedBits){

  //it's convenient to reverse true <-> false here

  vector<bool> result;
  while(number > 0) {
    if(number % 2 == 1) result.push_back(true);
    else result.push_back(false);
    number = number / 2;
    --usedBits;
  }

  while(usedBits > 0) {
    result.push_back(false);
    --usedBits;
  }

  return result;

}
std::string  AutomatonCal::encTrans(int k)
{

      //encode each discrete transition
      autoTemp_Trans* currtrans = this->autoTemp->temptrans;
      while(currtrans->previous != NULL)  //ensure return to the begin of   automatons clock list;
	     currtrans = (*currtrans).previous;
      std::string strtrans="";

      while(currtrans !=NULL)
      {

         strtrans =  strtrans + " " +  encDiscTran(currtrans, k);
         currtrans = currtrans->next;
      }
      //encStutTran(k) encode stutter transition
      strtrans = "( or " + strtrans + " " +  encStutTran(k) +")";
      std::cout << "Reading expressions all transistion :" <<strtrans << std::endl;
      return strtrans;

}


std::string  AutomatonCal::encClockrange(int k)
{
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string proc_name = this->procname;
     //std::string strkth = k2str.str();
     autoTemp_Clock * clocks = this->autoTemp->tempclocks;
     while(clocks->previous != NULL)  //ensure return to the begin of   automatons loc2invs list;
	  clocks = (*clocks).previous;
     std::string strrange = "( >= " +  proc_name + "_gtime_" +k2str.str() + " 0)";

     //encode each location invariant
     while(clocks!=NULL)
     {
          strrange =  strrange + " ( >= " + proc_name + "_" + clocks->clockname +"_" +k2str.str() + " 0) ";
          clocks = clocks->next;
     }
     return "( and " + strrange + " )";
}
std::string  AutomatonCal::encDiscTran( autoTemp_Trans* tran, int k)
{
     /*
      autoTemp_Reset* currreset = this->autoTemp->temptrans->reset;
      return this->encReset(currreset);
     */
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string strtran="";
    std::vector <std::string> compare_vars;

     std::string strloc2inv;

     autoTemp_Action* tranactions = tran->actions;
     if(tranactions != NULL)
     {
        while(tranactions->previous != NULL)  //ensure return to the begin of   automatons clock list;
	    tranactions = (*tranactions).previous;
     }

     std::string straction ="";
     int counter_action = 0;
     while(tranactions != NULL)
     {
         autoTemp_Action* actions = this->autoTemp->tempactions;
         while(actions != NULL)
         {
            if(actions->actionName == tranactions->actionName)
            {
                 straction =  straction + " " + actions->actionName  + "_" + k1str.str() ;
            }else
            {
                 straction = straction + " ( not " + actions->actionName  + "_" + k1str.str() +")";
            }
            actions = actions->next;
         }
      }

      strtran = "( and " + encLocation(tran->source,k-1) + " " + straction + " " + encGlobalClockGuard(tran->source,tran->globalclock_guard, k) + " " + encLocalClockGuard(tran->localclock_guard, k) + " " + encVarsGuard(tran->var_guard, k) + " " + encGlobalReset(tran->globalreset, k) + " " + encLocalReset(tran->localreset, k) +" " + encVarReset(tran->assignment, k) + " " + encLocation(tran->target,k) + ") ";
	  std::cout << "Reading expressions dis transistion :" <<strtran << std::endl;
      return strtran;
}
std::string AutomatonCal::encLocationInv(std::string location_name, int k, std::set<std::string> &compare_vars)
{
     stringstream k1str;
     k1str<<k-1;
     std::string strLocationInv="";
     std::string procname = this->procname;
	autoTemp_Locat2inv* currLoc2InvaExpr = autoTemp->temploc2invs;
	if(currLoc2InvaExpr!=NULL)
	   while(currLoc2InvaExpr->previous!=NULL)
	     currLoc2InvaExpr =  (*currLoc2InvaExpr).previous;
	while(currLoc2InvaExpr!=NULL)
	{
		if(currLoc2InvaExpr->locatname == location_name)
		{
			autoTemp_InvarExpr* currExpr = currLoc2InvaExpr->invariant;
			if(currExpr != NULL)
	          while(currExpr->previous != NULL)
	             currExpr =  (*currExpr).previous;
	        while(currExpr!=NULL)
	        {
				strLocationInv = strLocationInv + " ( " + currExpr->oper + " ( - " + procname + "_gtime_" + k1str.str() + " "  + currExpr->left_content + "_" + k1str.str() + ") " + currExpr->right_content + ") ";
			    shared_Clocks* currClock = this->sharedClocks;
			    if(currClock!=NULL)
			        while(currClock->previous != NULL)
			           currClock = (*currClock).previous;
			    while(currClock!=NULL)
			    {
				   if(currExpr->left_content == currClock->paramname)
				   {
				       compare_vars.insert(currClock->paramname);
				       //std::cout<<currExpr->left_content<<" 11:11 "<<currClock->paramname<<":"<<compare_vars.size()<<std::endl;
				   }
				       currClock = currClock->next;
				}
				currExpr =currExpr->next;
			}
		}
		currLoc2InvaExpr = currLoc2InvaExpr->next;
	}
	return strLocationInv;
}

std::string  AutomatonCal::encLocation(std::string name,int k)
{
    int integerEncoding = 0;
    map<std::string, int>::iterator  iter;
    iter = this->location2int.find(name);
    if( iter != this->location2int.end() )
    {
        integerEncoding = iter->second;
    }

    vector<bool> binval = int2binvect(integerEncoding, this->bitsNo);
    stringstream ss;
    if(binval.size() == 1)
    {
       if(binval[0])
       {
          ss << this->procname<<"_loc" << 0 << "_" <<k ;
       }
       else
       {
          ss << "( not " << this->procname<<"_loc" << 0 << "_" << k << ")";
       }
    }
    else
    {
      for(size_t i = 0; i < binval.size() - 1; ++i)
      {
        if(binval[i])
           ss << this->procname<<"_loc" << i << "_" <<k << " ";
        else
          ss << " ( not " << this->procname<<"_loc" << i <<"_" << k << ") ";
      }

      if(binval[binval.size()-1])
          ss <<" " << this->procname<<"_loc" << (binval.size() - 1) << "_" << k ;
      else
          ss << " ( not " << this->procname<<"_loc" << (binval.size() - 1 ) << "_" << k << ")";
   }
   std::cout << "Reading Location:" <<ss.str()<< std::endl;
   return ss.str();
}



std::string  AutomatonCal::encLocationEqual(int k)
{
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string proc_name = this->procname;
     std::string stuttran = "";

    for(size_t i = 0; i < this->bitsNo; ++i) {
       stringstream istr;
       istr<<i;
       stuttran = stuttran + " ( = " +proc_name + "_loc" + istr.str() +"_" + k2str.str() + " " + proc_name + "_loc" + istr.str() + "_" +k1str.str() + ")";
    }
    return stuttran;
}

std::string  AutomatonCal::encStutTran(int k)
{
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string proc_name = this->procname;
     std::string stuttran = encLocationEqual(k);

    //no internal action is true
    autoTemp_Action* actions = this->autoTemp->tempactions;
    if(actions != NULL)
    {
        while(actions->previous != NULL)  //ensure return to the begin of   automatons clock list;
	    actions = (*actions).previous;
     }
    while(actions != NULL)
    {
         stuttran = stuttran + " ( not " + actions->actionName +"_" + k1str.str() + ")";
         actions = actions->next;
    }

     autoTemp_Clock* clocks = this->autoTemp->tempclocks;
     if(clocks!=NULL)
     while(clocks->previous != NULL)  //ensure return to the begin of   automatons clock list;
	   clocks = (*clocks).previous;
     stuttran = stuttran + " ( >= ( - " + proc_name + "_gtime_" + k2str.str() + " " + proc_name + "_gtime_" + k1str.str() + ") 0)";
     while(clocks != NULL)
     {
          stuttran =  stuttran + " ( = " +proc_name + "_" + clocks->clockname +"_" +k2str.str() + " " + proc_name + "_" + clocks->clockname +"_" + k1str.str() + ")";
         clocks = clocks->next;
     }

     //no global varible is reseted by any process
     shared_Vars*  vars =this->sharedVars;
     if(vars !=NULL)
     {
        while(vars->previous != NULL)  //ensure return to the begin of   automatons clock list;
	        vars = (*vars).previous;
        while(vars != NULL)
        {
            stuttran = stuttran + " ( not " + proc_name + "_" + vars->paramname + "_w_" + k1str.str() + ") ( not " + proc_name + "_" + vars->paramname + "_r_" + k1str.str() + ")";
            vars = vars->next;
        }
     }

     shared_Bools*  bools =this->sharedBools;
     if(vars !=NULL)
     {
        while(bools->previous != NULL)  //ensure return to the begin of   automatons clock list;
	      bools = (*bools).previous;
        while(bools != NULL)
        {
            stuttran = stuttran + " ( not " + proc_name + "_" + bools->paramname + "_w_" + k1str.str() + ") ( not " + proc_name + "_" + bools->paramname + "_r_" + k1str.str() + ")";
            bools = bools->next;
        }
     }

     shared_Clocks*  shareclocks =this->sharedClocks;
     if(vars !=NULL)
     {
        while(shareclocks->previous != NULL)  //ensure return to the begin of   automatons clock list;
	      shareclocks = (*shareclocks).previous;
        while(shareclocks != NULL)
        {
            stuttran = stuttran + " ( not " + proc_name + "_" + shareclocks->paramname + "_w_" + k1str.str() + ") ( not " + proc_name + "_" + shareclocks->paramname + "_r_" + k1str.str() + ")";
            shareclocks = shareclocks->next;
        }
     }
     stuttran = "( and " + stuttran + ")";
    // std::cout << "Reading expressions from stutter transition:" <<stuttran<< std::endl;
     return stuttran;
}


std::string  AutomatonCal::encLocalClockGuard(autoTemp_Expr* guard ,int k)
{
    if(guard!=NULL)
      return this->encExpr(guard, k);
    else
      return "";

}


std::string  AutomatonCal::encGlobalClockGuard(std::string location_name, autoTemp_Expr* guard ,int k)
{
     std::string str_guard="";
     std::set <std::string> compare_vars;
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;

      str_guard = this-> encLocationInv(location_name, k,compare_vars);

      if(guard!=NULL)
         str_guard = str_guard + " " + this->encSharedClockExpr(guard, k, compare_vars);


      shared_Clocks* clocks = this->sharedClocks;
      if(clocks != NULL)
      {
	    while(clocks->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	       clocks = (*clocks).previous;
      }
      while(clocks!=NULL)
      {
    	  bool flag= false;
    	  set<std::string>::iterator it = compare_vars.begin();
    	     
          while(it != compare_vars.end())
          {
    	      if(clocks->paramname == *it)
    	      {
    	          flag = true;
    	          break;
    	      }
    	      it++;
          }
          if(flag==false)
          {
              str_guard= "( not " + proc_name +  "_" + clocks->paramname + "_r_" +  k1str.str() +") " +  str_guard ;
          }
          else
          {
              str_guard = " ( <= " + clocks->paramname + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() + ") ( >= rtime_" +  clocks->paramname + "_"+ k2str.str() +  " " +  proc_name + "_gtime_" +  k1str.str() + ") " + proc_name + "_" + clocks->paramname + "_r_" +  k1str.str()+ " "  +  str_guard;
          }
          clocks=clocks->next;
      }
       
    std::cout << "Global clocks:" <<str_guard<< std::endl;
    return str_guard;

}

std::string  AutomatonCal::encVarsGuard(autoTemp_Expr* guard ,int k)
{
     std::string str_guard="";
     shared_Vars*   sharedVars;
     shared_Bools*  sharedBools;
     std::set <std::string> compare_vars;
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;

     if(guard ==NULL)
     {
         shared_Vars* variables = this->sharedVars;
         if(variables != NULL)
         {
	         while(variables->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	            variables = (*variables).previous;
         }
    	 while(variables!=NULL)
    	 {
    	     str_guard = str_guard + " ( not " + proc_name +  "_" + variables->paramname + "_r_" +  k1str.str() +")";
             variables=variables->next;
    	 }
         shared_Bools* bools = this->sharedBools;
         if(bools != NULL)
         {
	         while(bools->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	            bools = (*bools).previous;
         }
    	 while(bools!=NULL)
    	 {
    	     str_guard = str_guard + " ( not " + proc_name +  "_" + bools->paramname + "_r_" +  k1str.str() +")";
             bools=bools->next;
    	 }
         return str_guard;
     }
     else
     {
         str_guard = this->encSharedVarExpr(guard, k,compare_vars);

         shared_Vars* variables = this->sharedVars;
         if(variables!=NULL)
	     while(variables->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	        variables = (*variables).previous;

         while(variables!=NULL)
    	 {
    	     bool flag= false;
    	     set<std::string>::iterator it = compare_vars.begin();
             while(it != compare_vars.end())
             {
    	        if(variables->paramname == *it)
    	        {
    	             flag = true;
    	             break;
    	        }
    	        it++;
             }
             if(flag==false)
             {
                str_guard= "( not " + proc_name +  "_" + variables->paramname + "_r_" +  k1str.str() +") " +  str_guard ;
             }
             else
             {
                 str_guard = "( >= rtime_" +  variables->paramname + "_" + k2str.str() + " " + proc_name + "_gtime_" +  k1str.str() + ") ( <= wtime_" + variables->paramname + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() + ") " + proc_name + "_" + variables->paramname + "_r_" +  k1str.str()+ " "  +  str_guard;
             }
              variables=variables->next;

    	   }


         shared_Bools* bools = this->sharedBools;
         if(bools!=NULL)
	     while(bools->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	        bools = (*bools).previous;
         while(bools!=NULL)
    	 {
    	     bool flag= false;
    	     set<std::string>::iterator it = compare_vars.begin();
             while(it != compare_vars.end())
             {
    	        if(bools->paramname == *it)
    	        {
    	             flag = true;
    	             break;
    	        }
    	        it++;
             }
             if(flag==false)
             {
                str_guard= "( not " + proc_name +  "_" + bools->paramname + "_r_" +  k1str.str() +") " +  str_guard ;
             }
             else
             {
                 str_guard = "( >= rtime_" +  k2str.str() + " " + proc_name + "_gtime_" +  k1str.str() + ") ( <= wtime_" + bools->paramname + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() + ") " + proc_name + "_" + bools->paramname + "_r_" +  k1str.str()+ " "  +  str_guard;
             }
             bools=bools->next;
    	   }
         }
   std::cout << "Var guard " <<str_guard<< std::endl;
         
    return str_guard;

}

std::string  AutomatonCal::encLocalReset(autoTemp_LocalReset* reset, int k)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     stringstream kstr;
     kstr<<k-2;
     std::string strreset="( >= ( - " + proc_name + "_gtime_" + k2str.str() + " " + proc_name + "_gtime_"+ k1str.str() + ") 0)";

     autoTemp_LocalReset* currLocalReset;
     autoTemp_Clock* currClock = this->autoTemp->tempclocks;
     if(currClock!=NULL)
     {
       while(currClock->previous != NULL)  //ensure return to the begin of   automatons clock list;
	     currClock = (*currClock).previous;
	 }

     while(currClock != NULL)
     {
          bool flag = false;
          currLocalReset = reset;
          if(currLocalReset!=NULL)
          {
            while(currLocalReset->previous != NULL)  //ensure return to the begin of   automatons reset list;
	           currLocalReset = (*currLocalReset).previous;
		   }
          while(currLocalReset != NULL)
          {
             if(currClock->clockname == currLocalReset->clockname)
             {
               strreset =strreset + " ( = " + proc_name + "_" +  currClock->clockname +  "_" + k2str.str() + " " + proc_name + "_gtime_" + k1str.str()+ ")";
                flag =true;
             }
             currLocalReset = currLocalReset->next;
          }
          if(flag != true)
          {
              strreset = strreset + " ( = " + proc_name + "_" + currClock->clockname +  "_" + k2str.str() + " " + proc_name + "_" + currClock->clockname +  "_" + k1str.str() + ")";
          }
          currClock = currClock->next;
     }
    // std::cout << "local reset " <<strreset<< std::endl;

     return strreset;
}

std::string  AutomatonCal::encGlobalReset(autoTemp_GlobalReset* reset, int k)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     std::string strreset="";
     std::string strGlobalInv="";

     shared_Clocks* currClock = this->sharedClocks;
     autoTemp_GlobalReset* currReset = reset;
     
     if(currClock!=NULL)
     {
       while(currClock->previous != NULL)  //ensure return to the begin of   automatons clock list;
	    currClock = (*currClock).previous;
	 }

     bool flag = false;
     //if reset is null  
     if(currReset == NULL)//when reset is null
     {
          while(currClock != NULL)
          {
             strreset = strreset + " ( not " + proc_name + "_" + currClock->paramname +  "_w_" + k1str.str() + ")";
             currClock = currClock->next;
          }
     }
     else
     {
       while(currClock != NULL)
       {
          bool flag = false;
          currReset = reset;
          while(currReset->previous != NULL)  //ensure return to the begin of   automatons reset list;
	        currReset = (*currReset).previous;
          while(currReset != NULL)
          {
             if(currClock->paramname == currReset->clockname)
             {
                strreset = strreset + " " + proc_name + "_" + currClock->paramname +  "_w_" + k1str.str() + " ( = " +  currClock->paramname +  "_" + k2str.str() + " " + proc_name + "_gtime_" + k1str.str()+ ") ( <= " +  currClock->paramname +  "_" + k1str.str() + " " + proc_name + "_gtime_" + k1str.str()+ ") ( <= rtime_" +  currClock->paramname +  "_" + k2str.str() + " " + proc_name + "_gtime_" + k1str.str()+ ")";
                strGlobalInv = strGlobalInv + encGlobalInv(currReset->clockname, k);
                flag =true;
             }       
             currReset = currReset->next;
          }
          if(flag != true)
          {
             strreset = strreset + " ( not " + proc_name + "_" + currClock->paramname +  "_w_" + k1str.str() + ")";
          }
          currClock = currClock->next;
       }
     }

     std::cout << "Expression for global reset:" <<strreset<< std::endl;
     return strreset + strGlobalInv;
}
std::string  AutomatonCal::encGlobalInv(std::string clock,int k)
{
     std::string currproc_name = this->procname;
     //std::map<autoProc_Body* , autoTemp_Body*> Proc2Autotemp = this->mapProc2Autotemp;
     stringstream k1str;
     k1str<<k-1;

     std::string strGlobalInv = "";
     
     for(map<autoProc_Body*, autoTemp_Body*>::const_iterator it = this->mapProc2Autotemp.begin(); it != this->mapProc2Autotemp.end(); ++it)
     {
		 std::string proc_name = (*it).first->autoname;
		 if( currproc_name != proc_name)
		 {
	        autoTemp_Locat2inv* Location2Inv = (*it).second->temploc2invs;
	        if(Location2Inv!=NULL)
		       while(Location2Inv->previous!=NULL)
		          Location2Inv = (*Location2Inv).previous;
	        while(Location2Inv!=NULL)
		    {
		       autoTemp_InvarExpr* InvExpr = Location2Inv->invariant;
		       if(InvExpr!=NULL)
		       while(InvExpr->previous!=NULL)
		         InvExpr = (*InvExpr).previous;
		       while(InvExpr!=NULL)
		       {
			      if(InvExpr->left_content == clock)
				  {
				     strGlobalInv = strGlobalInv + " ( or ( not ( and " + encLocation(Location2Inv->locatname, k-1) + "_" + k1str.str()  + ")) (" + InvExpr->oper + " ( - " +  proc_name + "_time" + "_" + k1str.str() + " " + InvExpr->left_content  + "_" + k1str.str() + ") " + InvExpr->right_content + ")";
				  }
			      InvExpr = InvExpr->next;
		       }
			   Location2Inv = Location2Inv->next;
	        }
		}
	 }
     return strGlobalInv;
}


std::string  AutomatonCal::encVarReset(autoTemp_Assignment* reset, int k)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     stringstream kstr;
     kstr<<k-2;
     std::string strreset="";

     autoTemp_Assignment* currVarsReset =reset;
     shared_Vars* currVars = this->sharedVars;
     shared_Bools* currBools = this->sharedBools;

     if(currVarsReset == NULL)
     {
		 if(currVars!=NULL)
		 {
            while(currVars->previous != NULL)  //ensure return to the begin of   automatons reset list;
	          currVars = (*currVars).previous;
		 }
		 while(currVars != NULL)
		 {
			strreset = strreset + " ( not " + proc_name  + "_" +  currVars->paramname + "_w_" +  k1str.str() + ")";
	        currVars = currVars->next;
		 }
		 
		 if(currBools!=NULL)
		 {
            while(currBools->previous != NULL)  //ensure return to the begin of   automatons reset list;
	          currBools = (*currBools).previous;
		 }
		 while(currBools != NULL)
		 {
			strreset = strreset + " ( not " + proc_name  + "_" +  currBools->paramname + "_w_" +  k1str.str() + ")";
	        currBools = currBools->next;
		 }
	 }else
	 {
    
		 if(currVars!=NULL)
		 {
            while(currVars->previous != NULL)  //ensure return to the begin of   automatons reset list;
	          currVars = (*currVars).previous;
		 }
		 
		 if(currBools!=NULL)
		 {
            while(currBools->previous != NULL)  //ensure return to the begin of   automatons reset list;
	          currBools = (*currBools).previous;
		 }


		 while(currVars != NULL)
		 {
		    bool flag = false;
		    currVarsReset = reset;
		    while(currVarsReset->previous != NULL)
		      currVarsReset = (*currVarsReset).previous;
		    while(currVarsReset != NULL)
		    {
                if(currVars->paramname == currVarsReset->var_name)//reset golbal variable
                {
                   if(currVarsReset->valuetype == 0)//constant
                   {
                      strreset = proc_name  + "_" +  currVars->paramname + "_w_" +  k1str.str() + " " + strreset + " ( = " + currVarsReset->var_name +  "_" + k2str.str() + " " + currVarsReset->value + ") ( <= wtime_" + currVarsReset->var_name + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( <= rtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( >= wtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +")";
                   }
                   if(currVarsReset->valuetype == 1)//parameter
                   {

                      std::string strvalue;
                      autoProc_Param* procargs = this->procParam;
                      autoTemp_Param* tempargs = this->autoTemp->tmepparams;
	                  while(procargs->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	                    procargs = (*procargs).previous;
	                  while(tempargs->previous != NULL)  //ensure return to the begin of template automata parameter list;
	                    tempargs = (*tempargs).previous;
                      while(tempargs != NULL)//map to real argument
                      {
                         if(tempargs->paramname == currVarsReset->value)
                         {
                             strvalue = procargs->paramname;
                             break;
                         }
                         procargs = (*procargs).next;
	                     tempargs = (*tempargs).next;
                      }
                      strreset = proc_name  + "_" +  currVars->paramname + "_w_" +  k1str.str() + " " + strreset + " ( = " + currVarsReset->var_name +  "_" + k2str.str() + " " + strvalue + ") ( <= wtime_" + currVarsReset->var_name + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( <= rtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( >= wtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +")";
                   }
                   flag =true;
                }
               currVarsReset = currVarsReset->next;
             }
             if(flag == false)
             {
                strreset = strreset + " ( not " + proc_name + "_" + currVars->paramname +  "_w_" + k1str.str() + ")";
			 }
			 

             currVars = currVars->next;
		 }
		 
		 if(currBools != NULL)
		 {
            currVarsReset =reset;
		    while(currVarsReset->previous != NULL)
		       currVarsReset = (*currVarsReset).previous;
		   }
		 while(currBools != NULL)
		 {
		    bool flag = false;
		    while(currVarsReset != NULL)
		    {
                if(currBools->paramname == currVarsReset->var_name)//reset golbal variable
                {
                   if(currVarsReset->valuetype == 0)//constant
                   {
                      strreset = proc_name  + "_" +  currBools->paramname + "_w_" +  k1str.str() + " " + strreset + " ( = " + currVarsReset->var_name +  "_" + k2str.str() + " " + currVarsReset->value + ") ( <= wtime_" + currVarsReset->var_name + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( <= rtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( >= wtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +")";
                   }
                   if(currVarsReset->valuetype == 1)//parameter
                   {

                      std::string strvalue;
                      autoProc_Param* procargs = this->procParam;
                      autoTemp_Param* tempargs = this->autoTemp->tmepparams;
	                  while(procargs->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	                    procargs = (*procargs).previous;
	                  while(tempargs->previous != NULL)  //ensure return to the begin of template automata parameter list;
	                    tempargs = (*tempargs).previous;
                      while(tempargs != NULL)//map to real argument
                      {
                         if(tempargs->paramname == currVarsReset->value)
                         {
                             strvalue = procargs->paramname;
                             break;
                         }
                         procargs = (*procargs).next;
	                     tempargs = (*tempargs).next;
                      }
                      strreset = proc_name  + "_" +  currBools->paramname + "_w_" +  k1str.str() + " " + strreset + " ( = " + currVarsReset->var_name +  "_" + k2str.str() + " " + strvalue + ") ( <= wtime_" + currVarsReset->var_name + "_" + k1str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( <= rtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +") ( >= wtime_" + currVarsReset->var_name + "_" + k2str.str() + " " +  proc_name + "_gtime_" +  k1str.str() +")";
                   }
                   flag =true;
                }
               currVarsReset = currVarsReset->next;
             }
             if(flag == false)
             {
                strreset = strreset + " ( not " + proc_name + "_" + currBools->paramname +  "_w_" + k1str.str() + ")";
			 }
             currBools = currBools->next;
		 }

	 }
   std::cout << "vars reset " <<strreset<< std::endl;

     return strreset;
}
std::string  AutomatonCal::encSharedVarExpr(autoTemp_Expr* expr, int k, std::set<std::string> &compare_vars)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     stringstream kstr;
     kstr<<k-2;
     std::string strguard="";

     //std::vector<std::string> compare_var;

     if(expr->nodetype == 7 ) //operator
     {
		 
         strguard = strguard + " " + encSharedClockExpr(expr->left, k ,compare_vars) + " " + encSharedClockExpr(expr->right, k, compare_vars) + " ";
     }
     if(expr->nodetype == 0 ) //realtion
     {
		 
         strguard = strguard + " (" + expr->content + " " + encSharedClockExpr(expr->left, k ,compare_vars) + " " + encSharedClockExpr(expr->right, k, compare_vars) + ") ";
     }
     if(expr->nodetype == 6 ) //neg operator
     {
          strguard = "( not "+ encSharedVarExpr(expr->right, k, compare_vars) + ")";

     }
     if(expr->nodetype == 1 ) //constant
     {
         strguard = expr->content;
     }

     if(expr->nodetype == 2 ) //parameter
     {
           autoProc_Param* procargs = this->procParam;
           autoTemp_Param* tempargs = this->autoTemp->tmepparams;
	       while(procargs->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	           procargs = (*procargs).previous;
	       while(tempargs->previous != NULL)  //ensure return to the begin of template automata parameter list;
	           tempargs = (*tempargs).previous;
           while(tempargs != NULL)//map to real argument
           {
              if(tempargs->paramname == expr->content)
              {
                  strguard = procargs->paramname;
                  break;
              }
              procargs = (*procargs).next;
	          tempargs = (*tempargs).next;
           }

     }
     if(expr->nodetype == 3 ) //variable
     {
         strguard =  expr->content + "_" + k1str.str();
         compare_vars.insert(expr->content);

     }
     if(expr->nodetype == 4 ) //minus
     {
         strguard = "(" + expr->content + " " + encSharedVarExpr(expr->right, k, compare_vars) + " "  + encSharedVarExpr(expr->left, k, compare_vars) + ")";
     }
     if(expr->nodetype == 5 ) //variable for term
     {
         strguard =  expr->content + "_" + k1str.str();
         compare_vars.insert(expr->content);
     }

     return strguard;
}

std::string  AutomatonCal::encSharedClockExpr(autoTemp_Expr* expr, int k, std::set<std::string> &compare_vars)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     stringstream kstr;
     kstr<<k-2;
     std::string strguard="";

     if(expr->nodetype == 7 ) //operator
     {
		 
         strguard = strguard + " " + encSharedClockExpr(expr->left, k ,compare_vars) + " " + encSharedClockExpr(expr->right, k, compare_vars) + " ";
     }
     if(expr->nodetype == 0 ) //realtion
     {
		 
         strguard = strguard + " (" + expr->content + " " + encSharedClockExpr(expr->left, k ,compare_vars) + " " + encSharedClockExpr(expr->right, k, compare_vars) + ") ";
     }
     if(expr->nodetype == 6 ) //neg operator
     {
          strguard = "( not "+ encSharedClockExpr(expr->right, k, compare_vars) + ")";
     }
     if(expr->nodetype == 1 ) //constant
     {
         strguard = expr->content;
     }

     if(expr->nodetype == 2 ) //parameter
     {
           autoProc_Param* procargs = this->procParam;
           autoTemp_Param* tempargs = this->autoTemp->tmepparams;
	       while(procargs->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	           procargs = (*procargs).previous;
	       while(tempargs->previous != NULL)  //ensure return to the begin of template automata parameter list;
	           tempargs = (*tempargs).previous;
           while(tempargs != NULL)//map to real argument
           {
              if(tempargs->paramname == expr->content)
              {
                  strguard = procargs->paramname;
                  break;
              }
              procargs = (*procargs).next;
	          tempargs = (*tempargs).next;
           }
     }
     if(expr->nodetype == 3 ) //variable
     {
         strguard =  expr->content + "_" + k1str.str();
         compare_vars.insert(expr->content);
     }
     if(expr->nodetype == 4 ) //minus
     {
         strguard = "(" + expr->content + " " + encSharedClockExpr(expr->right, k, compare_vars) + " "  + encSharedClockExpr(expr->left, k, compare_vars) + ")";
     }
     if(expr->nodetype == 5 ) //variable for term
     {
         strguard = "( - " + proc_name + "_gtime_" + k1str.str() + " "  + expr->content + "_" + k1str.str() +")";
         compare_vars.insert(expr->content);
     }
     return strguard;
}

std::string  AutomatonCal::encExpr(autoTemp_Expr* expr, int k)
{
     std::string proc_name = this->procname;
     stringstream k1str;
     stringstream k2str;
     k1str<<k-1;
     k2str<<k;
     stringstream kstr;
     kstr<<k-2;
     stringstream ss;
     ss<<expr->nodetype;
     std::string strguard= "";

     //std::vector<std::string> compare_var;

     if(expr->nodetype == 7 ) //operator
     {

         strguard = strguard + " " + encExpr(expr->left, k) + " " + encExpr(expr->right, k);

     }
     if(expr->nodetype == 0 ) //operator
     {

         strguard = strguard + "( " + expr->content + " " + encExpr(expr->left, k) + " " + encExpr(expr->right, k) + ")";

     }
     
     if(expr->nodetype == 6 ) //neg operator
     {
          strguard = "( not " + encExpr(expr->right, k) + ")";

     }
     if(expr->nodetype == 1 ) //constant
     {
         strguard = expr->content;
     }

     if(expr->nodetype == 2 ) //parameter
     {
           autoProc_Param* procargs = this->procParam;
           autoTemp_Param* tempargs = this->autoTemp->tmepparams;
	       while(procargs->previous != NULL)  //ensure return to the begin of instant automatons parameter list;
	           procargs = (*procargs).previous;
	       while(tempargs->previous != NULL)  //ensure return to the begin of template automata parameter list;
	           tempargs = (*tempargs).previous;
           while(tempargs != NULL)//map to real argument
           {
              if(tempargs->paramname == expr->content)
              {
                  strguard = procargs->paramname;
                  break;
              }
              procargs = (*procargs).next;
	          tempargs = (*tempargs).next;
           }

     }
     if(expr->nodetype == 3 ) //variable
     {
         strguard =  proc_name + "_" + expr->content + "_" + k1str.str();

     }
     if(expr->nodetype == 4 ) //minus
     {
         strguard = "( " + expr->content + " " + encExpr(expr->right, k) + " "  + encExpr(expr->left, k) + ")";
     }
     if(expr->nodetype == 5 ) //variable for term
     {
         strguard = "( - " + proc_name + "_gtime_" + k1str.str() + " " + proc_name + "_" +  expr->content + "_" + k1str.str() +")";
     }


     return strguard ;
}

