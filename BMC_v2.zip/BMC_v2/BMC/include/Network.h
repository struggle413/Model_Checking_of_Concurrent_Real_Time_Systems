#ifndef NETWORK_H
#define NETWORK_H
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <iterator>

using namespace std;
/**************************************************************
 * Contains the property formula 0 for constant 1 for variable. *
 **************************************************************/
class autoProp_Expr
{

public:
    /// left calculation operand
    autoProp_Expr* 	left;

    /// right calculation operand
    autoProp_Expr* 	right;
    std::string content;
    std::string process;
    int nodetype;// 2 for constant 1 for variable 0 for operator

    explicit autoProp_Expr(std::string proc, std::string value,int type, autoProp_Expr* _left, autoProp_Expr* _right)
	:process(proc), content(value), nodetype(type), left(_left), right(_right)
    {
    }
    autoProp_Expr* setType(int type)
     {
        this->nodetype = type;
        return this;
     }
 
    virtual ~autoProp_Expr()
    {
/*
	delete left;
	delete right;
*/
    }

};

/**************************************************************
 * Contains the formula tree of a linear expression or reset. *
 * 0 for operator,1 for clock variable, 2 for constant,3 for  *
 * parameter(after instantation as global  variable)          *
 **************************************************************/
class autoTemp_InvarExpr
{

public:
    /// left calculation operand
    autoTemp_InvarExpr* 	next;

    /// right calculation operand
    autoTemp_InvarExpr* 	previous;
    std::string left_content;
    std::string right_content;
    std::string oper;
    int type;

    explicit autoTemp_InvarExpr(std::string _left_content, std::string _oper, std::string _right_content, int _type, autoTemp_InvarExpr* _left, autoTemp_InvarExpr* _right)
	: left_content(_left_content), oper(_oper), right_content(_right_content), type(_type), next(_left), previous(_right)
    {
    }

    virtual ~autoTemp_InvarExpr()
    {
/*
	delete left;
	delete right;
*/
    }

};


/**************************************************************
 * List of locations with invariant, where invariant is in form 
 *  of fTree.    *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_Locat2inv 
{

public:
    /// forward calculation operand
    autoTemp_Locat2inv* 	previous;

    /// back calculation operand
    autoTemp_Locat2inv* 	next;
    std::string locatname;
    autoTemp_InvarExpr* invariant;

    explicit autoTemp_Locat2inv(std::string name,autoTemp_InvarExpr* invar, autoTemp_Locat2inv* _previous, autoTemp_Locat2inv* _next)
	: locatname(name),invariant(invar), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Locat2inv()
    {
/*
	delete previous;
	delete next;
        delete invariant;*/
    }

};
/**************************************************************
 * Contains the formula tree of a linear expression or reset. *
 * 0 for operator,1 for clock variable, 2 for constant,3 for  *
 * parameter(after instantation as global  variable)          *
 **************************************************************/
class autoTemp_Expr
{

public:
    /// left calculation operand
    autoTemp_Expr* 	left;

    /// right calculation operand
    autoTemp_Expr* 	right;
    std::string content;
    int nodetype;
    autoTemp_Expr* setType(int type)
     {
        this->nodetype = type;
        return this;
     }
    explicit autoTemp_Expr(std::string value,int type, autoTemp_Expr* _left, autoTemp_Expr* _right)
	: content(value),nodetype(type), left(_left), right(_right)
    {
    }

    virtual ~autoTemp_Expr()
    {
/*
	delete left;
	delete right;
*/
    }

};

/**************************************************************
 * List of locations  *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_Locat
{

public:
    /// left calculation operand
    autoTemp_Locat* 	previous;

    /// right calculation operand
    autoTemp_Locat* 	next;
    std::string locatname;
    explicit autoTemp_Locat(std::string name, autoTemp_Locat* _previous, autoTemp_Locat* _next)
	: locatname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Locat()
    {
/*
	delete previous;
	delete next;
*/
    }

};


/**************************************************************
 * List of parameter of template of automata *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_Param 
{

public:
    /// left calculation operand
    autoTemp_Param* 	previous;

    /// right calculation operand
    autoTemp_Param* 	next;
    std::string paramname;
    

    explicit autoTemp_Param (std::string name, autoTemp_Param* _previous, autoTemp_Param* _next)
	: paramname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Param()
    {
/*
	delete previous;
	delete next;
*/
    }

};

/**************************************************************
 * List of clock  *
 * This is bidirectional list of clock variables for current autom. *
 **************************************************************/
class autoTemp_Clock 
{

public:
    /// left calculation operand
    autoTemp_Clock* 	previous;

    /// right calculation operand
    autoTemp_Clock* 	next;
    std::string clockname;
    std::string max_l;
    std::string max_u;
    explicit autoTemp_Clock (std::string name, autoTemp_Clock* _previous, autoTemp_Clock* _next)
	: clockname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Clock()
    {
/*
	delete previous;
	delete next;
*/
    }

};

/**************************************************************
 * List of action  *
 * This is bidirectional list of action variables for current autom. *
 **************************************************************/
class autoTemp_Action 
{

public:
    /// left calculation operand
    autoTemp_Action* 	previous;

    /// right calculation operand
    autoTemp_Action* 	next;
    std::string actionName;
    

    explicit autoTemp_Action (std::string name, autoTemp_Action* _previous, autoTemp_Action* _next)
	: actionName(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Action()
    {
/*
	delete previous;
	delete next;
*/
    }

};
/**************************************************************
 * List of init  *
 * This is bidirectional list of action variables for current autom. *
 **************************************************************/
class autoTemp_Init 
{

public:
    /// left calculation operand
    autoTemp_Init* 	previous;

    /// right calculation operand
    autoTemp_Init* 	next;
    std::string initname;
    
    explicit autoTemp_Init (std::string name, autoTemp_Init* _previous, autoTemp_Init* _next)
	: initname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Init()
    {
	/*delete previous;
	delete next;*/

    }

};



/**************************************************************
 * List of locations with invariant, where invariant is in form 
 *  of fTree.    *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_GlobalReset 
{

public:
    /// forward calculation operand
    autoTemp_GlobalReset* 	previous;

    /// back calculation operand
    autoTemp_GlobalReset* 	next;
    std::string clockname;


    explicit autoTemp_GlobalReset(std::string name, autoTemp_GlobalReset* _previous, autoTemp_GlobalReset* _next)
	: clockname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_GlobalReset()
    {
	/*
        delete previous;
	    delete next;
    */
    }

};


/**************************************************************
 * List of locations with invariant, where invariant is in form 
 *  of fTree.    *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_LocalReset 
{

public:
    /// forward calculation operand
    autoTemp_LocalReset* 	previous;

    /// back calculation operand
    autoTemp_LocalReset* 	next;
    std::string clockname;


    explicit autoTemp_LocalReset(std::string name, autoTemp_LocalReset* _previous, autoTemp_LocalReset* _next)
	: clockname(name), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_LocalReset()
    {
	/*
        delete previous;
	delete next;
*/
    }

};
/**************************************************************
 * List of locations with invariant, where invariant is in form 
 *  of fTree.    *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_Assignment 
{

public:
    /// forward calculation operand
    autoTemp_Assignment* 	previous;

    /// back calculation operand
    autoTemp_Assignment* 	next;
    std::string var_name;
    std::string value;
    int valuetype;

    explicit autoTemp_Assignment(std::string name, std::string _value, int _type, autoTemp_Assignment* _previous, autoTemp_Assignment* _next)
	: var_name(name), value(_value),valuetype(_type), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Assignment()
    {
	/*
        delete previous;
	delete next;
*/
    }

};
/**************************************************************
 * List of transitions with target, action and source names,  *
 * guard and reset (fTrees).                                  *
 * This is bidirectional list of locations for current autom. *
 **************************************************************/
class autoTemp_Trans
{

public:
    /// forward calculation operand
    autoTemp_Trans* 	previous;

    /// back calculation operand
    autoTemp_Trans* 	next;
    std::string source;
    std::string target;
    autoTemp_Action* actions ;

    autoTemp_Expr* globalclock_guard;
    autoTemp_Expr* localclock_guard;

    autoTemp_Expr* var_guard;

    autoTemp_GlobalReset* globalreset;
    autoTemp_LocalReset* localreset;

    autoTemp_Assignment* assignment;
    explicit autoTemp_Trans(std::string _source, autoTemp_Action* _actionName, autoTemp_Expr* _globalclock_guard, autoTemp_Expr* _localclock_guard, autoTemp_Expr* _var_guard, autoTemp_GlobalReset* _globalreset, autoTemp_LocalReset* _localreset, autoTemp_Assignment* _assignment, std::string _target, autoTemp_Trans* _previous, autoTemp_Trans* _next)
	: source(_source), actions(_actionName), globalclock_guard(_globalclock_guard), localclock_guard(_localclock_guard), var_guard(_var_guard), globalreset(_globalreset), localreset(_localreset), assignment(_assignment), target(_target), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Trans()
    {
/*
	delete previous;
	delete next;
        delete guard;
        delete reset;
*/
    }

};

/**************************************************************
 * Bidirectional list of template for automata.               *
 **************************************************************/
class autoTemp_Body
{

public:
    /// forward calculation operand
    autoTemp_Body* 	previous;

    /// back calculation operand
    autoTemp_Body* 	next;
    std::string tempname;
    autoTemp_Param* tmepparams;
    autoTemp_Locat* templocats;
    autoTemp_Action* tempactions;
    autoTemp_Init* tempinits;
    autoTemp_Clock* tempclocks;
    autoTemp_Locat2inv* temploc2invs;
    autoTemp_Trans*  temptrans;
   
    explicit autoTemp_Body(std::string name, autoTemp_Param* params,autoTemp_Locat* locats, autoTemp_Action* actions, autoTemp_Init* inits,autoTemp_Clock* clocks, autoTemp_Locat2inv* loc2invs, autoTemp_Trans* trans, autoTemp_Body* _previous, autoTemp_Body* _next)
	: tempname(name), tmepparams(params), templocats(locats),tempactions(actions),tempinits(inits), tempclocks(clocks),temploc2invs(loc2invs),temptrans(trans), previous(_previous), next(_next)
    {
    }

    virtual ~autoTemp_Body()
    {
/*
	delete previous;
	delete next;
        delete tmepparams;
        delete templocats;
	delete tempactions;
	delete tempinits;
        delete tempclocks;
        delete temploc2invs;
        delete temptrans;
*/
    }

};

/**************************************************************
 * Contains the parameter bounded after instantation of automata.*
 **************************************************************/
class shared_Vars
{

public:
    /// left calculation operand
    shared_Vars* 	previous;

    /// right calculation operand
    shared_Vars* 	next;
    std::string paramname;
    std::string lbounded; //for low bounded of variable
    std::string ubounded; //for up bounded of variable

    explicit shared_Vars(std::string name,std::string low, std::string  up, shared_Vars* _previous, shared_Vars* _next)
	: paramname(name),lbounded(low),ubounded(up), previous(_previous), next(_next)
    {
    }

    virtual ~shared_Vars()
    {
/*
	delete previous;
	delete next;
*/
    }

};
/**************************************************************
 * Contains the parameter bounded after instantation of automata.*
 **************************************************************/
class shared_Clocks
{

public:
    /// left calculation operand
    shared_Clocks* 	previous;

    /// right calculation operand
    shared_Clocks* 	next;
    std::string paramname;

    explicit shared_Clocks(std::string name, shared_Clocks* _previous, shared_Clocks* _next)
	: paramname(name), previous(_previous), next(_next)
    {
    }

    virtual ~shared_Clocks()
    {
/*
	delete previous;
	delete next;
*/
    }

};


/**************************************************************
 * Contains the parameter bounded after instantation of automata.*
 **************************************************************/
class shared_Bools
{

public:
    /// left calculation operand
    shared_Bools* 	previous;

    /// right calculation operand
    shared_Bools* 	next;
    std::string paramname;

    explicit shared_Bools(std::string name, shared_Bools* _previous, shared_Bools* _next)
	: paramname(name), previous(_previous), next(_next)
    {
    }

    virtual ~shared_Bools()
    {
/*
	delete previous;
	delete next;
*/
    }

};
/**************************************************************
 * Contains the parameter of instantation of automata.       *
 **************************************************************/
class autoProc_Param
{

public:
    /// left calculation operand
    autoProc_Param* 	previous;
    /// right calculation operand
    autoProc_Param* 	next;
    std::string paramname;
    std::string lbounded; //for low bounded of variable
    std::string ubounded; //for up bounded of variable
    int nodetype;//0 constant,1 for variable

    explicit autoProc_Param(std::string name,int type,std::string low, std::string  up, autoProc_Param* _previous, autoProc_Param* _next)
	: paramname(name),nodetype(type),lbounded(low),ubounded(up), previous(_previous), next(_next)
    {
    }

    virtual ~autoProc_Param()
    {
/*
	delete previous;
	delete next;
*/
    }

};


/**************************************************************
 * Bidirectional list of automata that instantaion in  network.*
 **************************************************************/
class autoProc_Body
{

public:
    /// forward calculation operand
    autoProc_Body* 	previous;

    /// back calculation operand
    autoProc_Body* 	next;
    std::string autoname;
    std::string tempname;

    autoProc_Param* params;
   
    explicit autoProc_Body(std::string _autoname, std::string _tempname, autoProc_Param* _params, autoProc_Body* _previous, autoProc_Body* _next)
	: autoname(_autoname), tempname(_tempname), params(_params), previous(_previous), next(_next)
    {
    }

    virtual ~autoProc_Body()
    {
/*
        if(previous!=NULL)
	    delete previous;
        if(next!=NULL)
	    delete next;
        if(params!=NULL)
            delete params;
*/
    }

};


/**************************************************************
 * Contains the parser model.                                 *
 **************************************************************/

class autoNetwork
{
public:
   // std::string netName;
    shared_Vars*   sharedVars;
    shared_Clocks* sharedClocks;
    shared_Bools* sharedBools;
    std::set<std::string>  actionlist;

    autoTemp_Body* autoTemps;  //contain list for automata template
    autoProc_Body* autoProcs;   // instantation automata list in network
    autoProp_Expr* autoProp;
    std::map<autoProc_Body* , autoTemp_Body*> mapProc2Autotemp;
    //std::map<std::string, std::string, std::string> mapProclcation2enclocation; //map process location to it's encoding

    autoTemp_Body* serachAutoTemp(std::string tempname);
    std::string encTrans(int k);
    std::string encActionSyn(int k);
    std::string encSharedVarSyn(int k);
    std::string encSharedBoolSyn(int k);
    std::string encInit();

    std::string encSharedClockSyn(int k);
    std::string encPropFormula(autoProp_Expr* expr, int k);
    std::string encTimesyn(int k);
    std::string encLastGlobalInv(int k);

    void init();

    virtual ~autoNetwork()
    { 
    }
   
    
};



#endif
