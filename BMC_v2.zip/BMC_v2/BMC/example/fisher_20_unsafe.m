MODULE Process Fischer(pid,id,k,d)
{
    VAR 
        Location : {ideal,req, wait, cs}
        Init:{ideal}
        Clock: {x} 
    INVS
        req : {x <= d}
    TRANS
        {FROM ideal;  GUARD id = 0 ; RESET x := 0; GOTO req}
        {FROM req; RESET x := 0, id := pid;  GOTO wait}
        {FROM wait;  GUARD ((not(id = pid)) and x >= k) ; GOTO ideal}
        {FROM wait;  GUARD id = pid and x >= k ; GOTO cs}
        {FROM cs; RESET x := 0, id := 0;  GOTO ideal}

}

NETSYSTEMS
{
    VAR 
    id 0...20;
    PRO
    p1:Fischer(1,id,6,7);
    p2:Fischer(2,id,6,7);
    p3:Fischer(3,id,6,7);
    p4:Fischer(4,id,6,7);
    p5:Fischer(5,id,6,7);
    p6:Fischer(6,id,6,7);
    p7:Fischer(7,id,6,7);
    p8:Fischer(8,id,6,7);
    p9:Fischer(9,id,6,7);
    p10:Fischer(10,id,6,7);
    p11:Fischer(11,id,6,7);
    p12:Fischer(12,id,6,7);
    p13:Fischer(13,id,6,7);
    p14:Fischer(14,id,6,7);
    p15:Fischer(15,id,6,7);
    p16:Fischer(16,id,6,7);
    p17:Fischer(17,id,6,7);
    p18:Fischer(18,id,6,7);
    p19:Fischer(19,id,6,7);
    p20:Fischer(20,id,6,7);
    INVARSPEC (p1.cs and p2.cs)
}

