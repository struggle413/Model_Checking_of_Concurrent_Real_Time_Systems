// A Bison parser, made by GNU Bison 3.0.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2013 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// Take the name prefix into account.
#define yylex   examplelex

// First part of user declarations.
#line 2 "parser.yy" // lalr1.cc:399
 /*** C/C++ Declarations ***/

#include <stdio.h>
#include <string>
#include <vector>
#include <typeinfo>
#include <exception>
#include "Network.h"
using namespace std;

#line 49 "parser.cc" // lalr1.cc:399

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

#include "tokens.h"

// User implementation prologue.
#line 199 "parser.yy" // lalr1.cc:407


#include "driver.h"
#include "scanner.hh"

/* this "connects" the bison parser in the driver to the flex scanner class
 * object. it defines the yylex() function call to pull the next token from the
 * current lexer object of the driver context. */
#undef yylex
#define yylex driver.lexer->lex


#line 75 "parser.cc" // lalr1.cc:407


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (/*CONSTCOND*/ false)
# endif


// Suppress unused-variable warnings by "using" E.
#define YYUSE(E) ((void) (E))

// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << std::endl;                  \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE(Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void>(0)
# define YY_STACK_PRINT()                static_cast<void>(0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyempty = true)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)


namespace example {
#line 161 "parser.cc" // lalr1.cc:474

  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  Parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr = "";
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              // Fall through.
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }


  /// Build a parser object.
  Parser::Parser (class Driver& driver_yyarg)
    :
#if YYDEBUG
      yydebug_ (false),
      yycdebug_ (&std::cerr),
#endif
      driver (driver_yyarg)
  {}

  Parser::~Parser ()
  {}


  /*---------------.
  | Symbol types.  |
  `---------------*/

  inline
  Parser::syntax_error::syntax_error (const location_type& l, const std::string& m)
    : std::runtime_error (m)
    , location (l)
  {}

  // basic_symbol.
  template <typename Base>
  inline
  Parser::basic_symbol<Base>::basic_symbol ()
    : value ()
  {}

  template <typename Base>
  inline
  Parser::basic_symbol<Base>::basic_symbol (const basic_symbol& other)
    : Base (other)
    , value ()
    , location (other.location)
  {
    value = other.value;
  }


  template <typename Base>
  inline
  Parser::basic_symbol<Base>::basic_symbol (typename Base::kind_type t, const semantic_type& v, const location_type& l)
    : Base (t)
    , value (v)
    , location (l)
  {}


  /// Constructor for valueless symbols.
  template <typename Base>
  inline
  Parser::basic_symbol<Base>::basic_symbol (typename Base::kind_type t, const location_type& l)
    : Base (t)
    , value ()
    , location (l)
  {}

  template <typename Base>
  inline
  Parser::basic_symbol<Base>::~basic_symbol ()
  {
  }

  template <typename Base>
  inline
  void
  Parser::basic_symbol<Base>::move (basic_symbol& s)
  {
    super_type::move(s);
    value = s.value;
    location = s.location;
  }

  // by_type.
  inline
  Parser::by_type::by_type ()
     : type (empty)
  {}

  inline
  Parser::by_type::by_type (const by_type& other)
    : type (other.type)
  {}

  inline
  Parser::by_type::by_type (token_type t)
    : type (yytranslate_ (t))
  {}

  inline
  void
  Parser::by_type::move (by_type& that)
  {
    type = that.type;
    that.type = empty;
  }

  inline
  int
  Parser::by_type::type_get () const
  {
    return type;
  }


  // by_state.
  inline
  Parser::by_state::by_state ()
    : state (empty)
  {}

  inline
  Parser::by_state::by_state (const by_state& other)
    : state (other.state)
  {}

  inline
  void
  Parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.state = empty;
  }

  inline
  Parser::by_state::by_state (state_type s)
    : state (s)
  {}

  inline
  Parser::symbol_number_type
  Parser::by_state::type_get () const
  {
    return state == empty ? 0 : yystos_[state];
  }

  inline
  Parser::stack_symbol_type::stack_symbol_type ()
  {}


  inline
  Parser::stack_symbol_type::stack_symbol_type (state_type s, symbol_type& that)
    : super_type (s, that.location)
  {
    value = that.value;
    // that is emptied.
    that.type = empty;
  }

  inline
  Parser::stack_symbol_type&
  Parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    value = that.value;
    location = that.location;
    return *this;
  }


  template <typename Base>
  inline
  void
  Parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);

    // User destructor.
    switch (yysym.type_get ())
    {
            case 3: // INTEGER

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 380 "parser.cc" // lalr1.cc:599
        break;

      case 4: // IDENT

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 387 "parser.cc" // lalr1.cc:599
        break;

      case 26: // LOGVAL

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 394 "parser.cc" // lalr1.cc:599
        break;

      case 27: // OPERATOR

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 401 "parser.cc" // lalr1.cc:599
        break;

      case 28: // NEG

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 408 "parser.cc" // lalr1.cc:599
        break;

      case 29: // RELATION

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 415 "parser.cc" // lalr1.cc:599
        break;

      case 31: // MINUS

#line 194 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.stringVal); }
#line 422 "parser.cc" // lalr1.cc:599
        break;

      case 41: // constant

#line 195 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.autoTempExpr_type); }
#line 429 "parser.cc" // lalr1.cc:599
        break;

      case 42: // variable

#line 195 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.autoTempExpr_type); }
#line 436 "parser.cc" // lalr1.cc:599
        break;

      case 43: // term

#line 195 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.autoTempExpr_type); }
#line 443 "parser.cc" // lalr1.cc:599
        break;

      case 44: // atomexpr

#line 195 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.autoTempExpr_type); }
#line 450 "parser.cc" // lalr1.cc:599
        break;

      case 45: // expr

#line 195 "parser.yy" // lalr1.cc:599
        { delete (yysym.value.autoTempExpr_type); }
#line 457 "parser.cc" // lalr1.cc:599
        break;


      default:
        break;
    }
  }

#if YYDEBUG
  template <typename Base>
  void
  Parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " ("
        << yysym.location << ": ";
    YYUSE (yytype);
    yyo << ')';
  }
#endif

  inline
  void
  Parser::yypush_ (const char* m, state_type s, symbol_type& sym)
  {
    stack_symbol_type t (s, sym);
    yypush_ (m, t);
  }

  inline
  void
  Parser::yypush_ (const char* m, stack_symbol_type& s)
  {
    if (m)
      YY_SYMBOL_PRINT (m, s);
    yystack_.push (s);
  }

  inline
  void
  Parser::yypop_ (unsigned int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  Parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  Parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  Parser::debug_level_type
  Parser::debug_level () const
  {
    return yydebug_;
  }

  void
  Parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  inline Parser::state_type
  Parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  inline bool
  Parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  inline bool
  Parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  Parser::parse ()
  {
    /// Whether yyla contains a lookahead.
    bool yyempty = true;

    // State.
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

    // FIXME: This shoud be completely indented.  It is not yet to
    // avoid gratuitous conflicts when merging into the master branch.
    try
      {
    YYCDEBUG << "Starting parse" << std::endl;


    // User initialization code.
    #line 40 "parser.yy" // lalr1.cc:725
{
    // initialize the initial location object
    yyla.location.begin.filename = yyla.location.end.filename = &driver.streamname;
}

#line 594 "parser.cc" // lalr1.cc:725

    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, yyla);

    // A new symbol was pushed on the stack.
  yynewstate:
    YYCDEBUG << "Entering state " << yystack_[0].state << std::endl;

    // Accept?
    if (yystack_[0].state == yyfinal_)
      goto yyacceptlab;

    goto yybackup;

    // Backup.
  yybackup:

    // Try to take a decision without lookahead.
    yyn = yypact_[yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyempty)
      {
        YYCDEBUG << "Reading a token: ";
        try
          {
            yyla.type = yytranslate_ (yylex (&yyla.value, &yyla.location));
          }
        catch (const syntax_error& yyexc)
          {
            error (yyexc);
            goto yyerrlab1;
          }
        yyempty = false;
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      goto yydefault;

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Discard the token being shifted.
    yyempty = true;

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", yyn, yyla);
    goto yynewstate;

  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;

  /*-----------------------------.
  | yyreduce -- Do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_(yystack_[yylen].state, yyr1_[yyn]);
      /* If YYLEN is nonzero, implement the default value of the
         action: '$$ = $1'.  Otherwise, use the top of the stack.

         Otherwise, the following line sets YYLHS.VALUE to garbage.
         This behavior is undocumented and Bison users should not rely
         upon it.  */
      if (yylen)
        yylhs.value = yystack_[yylen - 1].value;
      else
        yylhs.value = yystack_[0].value;

      // Compute the default @$.
      {
        slice<stack_symbol_type, stack_type> slice (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, slice, yylen);
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
      try
        {
          switch (yyn)
            {
  case 2:
#line 217 "parser.yy" // lalr1.cc:847
    {
		 (yylhs.value.autoTempExpr_type) = new autoTemp_Expr(*(yystack_[0].value.stringVal), 1, NULL, NULL); 
                 delete (yystack_[0].value.stringVal);
	   }
#line 711 "parser.cc" // lalr1.cc:847
    break;

  case 3:
#line 222 "parser.yy" // lalr1.cc:847
    {
		 (yylhs.value.autoTempExpr_type) =  new autoTemp_Expr(*(yystack_[0].value.stringVal), 2, NULL, NULL); 
                 delete (yystack_[0].value.stringVal);
           }
#line 720 "parser.cc" // lalr1.cc:847
    break;

  case 4:
#line 228 "parser.yy" // lalr1.cc:847
    {
		 (yylhs.value.autoTempExpr_type) = new autoTemp_Expr(*(yystack_[0].value.stringVal), 3, NULL, NULL); 
                 delete (yystack_[0].value.stringVal);

	    }
#line 730 "parser.cc" // lalr1.cc:847
    break;

  case 5:
#line 234 "parser.yy" // lalr1.cc:847
    {
		 (yylhs.value.autoTempExpr_type) = new autoTemp_Expr(*(yystack_[1].value.stringVal), 4, (yystack_[2].value.autoTempExpr_type), (yystack_[0].value.autoTempExpr_type)); 	
                 delete (yystack_[1].value.stringVal);

           }
#line 740 "parser.cc" // lalr1.cc:847
    break;

  case 6:
#line 240 "parser.yy" // lalr1.cc:847
    {  
                (yylhs.value.autoTempExpr_type) = &(*(yystack_[0].value.autoTempExpr_type)->setType(5));
           }
#line 748 "parser.cc" // lalr1.cc:847
    break;

  case 7:
#line 245 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = (yystack_[1].value.autoTempExpr_type); }
#line 754 "parser.cc" // lalr1.cc:847
    break;

  case 8:
#line 248 "parser.yy" // lalr1.cc:847
    {	

		 (yylhs.value.autoTempExpr_type) = new autoTemp_Expr(*(yystack_[1].value.stringVal), 0, (yystack_[2].value.autoTempExpr_type), (yystack_[0].value.autoTempExpr_type)); 
                 delete (yystack_[1].value.stringVal);
	   }
#line 764 "parser.cc" // lalr1.cc:847
    break;

  case 9:
#line 255 "parser.yy" // lalr1.cc:847
    {		  
		 (yylhs.value.autoTempExpr_type) =  new autoTemp_Expr(*(yystack_[1].value.stringVal), 6, NULL, (yystack_[0].value.autoTempExpr_type)); 
                 delete (yystack_[1].value.stringVal);
           }
#line 773 "parser.cc" // lalr1.cc:847
    break;

  case 10:
#line 260 "parser.yy" // lalr1.cc:847
    {		  
		 (yylhs.value.autoTempExpr_type) = new autoTemp_Expr(*(yystack_[1].value.stringVal), 7, (yystack_[2].value.autoTempExpr_type), (yystack_[0].value.autoTempExpr_type)); 
                 delete (yystack_[1].value.stringVal);
           }
#line 782 "parser.cc" // lalr1.cc:847
    break;

  case 11:
#line 265 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempExpr_type) = (yystack_[1].value.autoTempExpr_type); }
#line 788 "parser.cc" // lalr1.cc:847
    break;

  case 12:
#line 267 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempExpr_type) = (yystack_[0].value.autoTempExpr_type); }
#line 794 "parser.cc" // lalr1.cc:847
    break;

  case 13:
#line 269 "parser.yy" // lalr1.cc:847
    {
              (yylhs.value.autoTempInvarExpr_type) = new autoTemp_InvarExpr(*(yystack_[2].value.stringVal), *(yystack_[1].value.stringVal), *(yystack_[0].value.stringVal), 0, NULL, NULL);
              delete (yystack_[2].value.stringVal);
              delete (yystack_[1].value.stringVal);
              delete (yystack_[0].value.stringVal);

          }
#line 806 "parser.cc" // lalr1.cc:847
    break;

  case 14:
#line 277 "parser.yy" // lalr1.cc:847
    {
              (yylhs.value.autoTempInvarExpr_type) = new autoTemp_InvarExpr(*(yystack_[2].value.stringVal), *(yystack_[1].value.stringVal), *(yystack_[0].value.stringVal), 1, NULL, NULL);
              delete (yystack_[2].value.stringVal);
              delete (yystack_[1].value.stringVal);
              delete (yystack_[0].value.stringVal);
          }
#line 817 "parser.cc" // lalr1.cc:847
    break;

  case 15:
#line 286 "parser.yy" // lalr1.cc:847
    {

                 (yylhs.value.autoTempParam_type) = new autoTemp_Param(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
            }
#line 827 "parser.cc" // lalr1.cc:847
    break;

  case 16:
#line 292 "parser.yy" // lalr1.cc:847
    {   (yylhs.value.autoTempParam_type) = NULL;   }
#line 833 "parser.cc" // lalr1.cc:847
    break;

  case 17:
#line 294 "parser.yy" // lalr1.cc:847
    {

                autoTemp_Param* currParam = (yystack_[0].value.autoTempParam_type);
                autoTemp_Param* nextParam = (yystack_[2].value.autoTempParam_type);
                (*currParam).next = nextParam;
	        if(nextParam != NULL) (*nextParam).previous = currParam;
		    (yylhs.value.autoTempParam_type) = currParam;

            }
#line 847 "parser.cc" // lalr1.cc:847
    break;

  case 18:
#line 304 "parser.yy" // lalr1.cc:847
    {   

                 (yylhs.value.autoTempParam_type) = (yystack_[0].value.autoTempParam_type);    }
#line 855 "parser.cc" // lalr1.cc:847
    break;

  case 19:
#line 311 "parser.yy" // lalr1.cc:847
    {

                 (yylhs.value.autoTempInit_type) = new autoTemp_Init(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 865 "parser.cc" // lalr1.cc:847
    break;

  case 20:
#line 317 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Init* currInit = (yystack_[0].value.autoTempInit_type);
                autoTemp_Init* nextInit = (yystack_[2].value.autoTempInit_type);
                (*currInit).next = nextInit;
	        if(nextInit != NULL) (*nextInit).previous = currInit;
	            (yylhs.value.autoTempInit_type) = currInit;
             }
#line 877 "parser.cc" // lalr1.cc:847
    break;

  case 21:
#line 325 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempInit_type) = (yystack_[0].value.autoTempInit_type);  }
#line 883 "parser.cc" // lalr1.cc:847
    break;

  case 22:
#line 327 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempInit_type) = (yystack_[1].value.autoTempInit_type); }
#line 889 "parser.cc" // lalr1.cc:847
    break;

  case 23:
#line 332 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempAction_type) = new autoTemp_Action(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 898 "parser.cc" // lalr1.cc:847
    break;

  case 24:
#line 337 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAction_type) = NULL; }
#line 904 "parser.cc" // lalr1.cc:847
    break;

  case 25:
#line 339 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Action* currAction = (yystack_[2].value.autoTempAction_type);
                autoTemp_Action* nextAction = (yystack_[0].value.autoTempAction_type);
                (*currAction).next = nextAction;
		         if(nextAction != NULL) (*nextAction).previous = currAction;
		        (yylhs.value.autoTempAction_type) = currAction;
             }
#line 916 "parser.cc" // lalr1.cc:847
    break;

  case 26:
#line 347 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempAction_type) = (yystack_[0].value.autoTempAction_type); }
#line 922 "parser.cc" // lalr1.cc:847
    break;

  case 27:
#line 349 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAction_type) = NULL; }
#line 928 "parser.cc" // lalr1.cc:847
    break;

  case 28:
#line 351 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempAction_type) = (yystack_[1].value.autoTempAction_type); }
#line 934 "parser.cc" // lalr1.cc:847
    break;

  case 29:
#line 356 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempLocat_type) = new autoTemp_Locat(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 943 "parser.cc" // lalr1.cc:847
    break;

  case 30:
#line 361 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Locat* currLocation = (yystack_[2].value.autoTempLocat_type);
                autoTemp_Locat* nextLocation = (yystack_[0].value.autoTempLocat_type);
                (*currLocation).next = nextLocation;
	        	if(nextLocation != NULL) (*nextLocation).previous = currLocation;
	        	 (yylhs.value.autoTempLocat_type) = currLocation;
             }
#line 955 "parser.cc" // lalr1.cc:847
    break;

  case 31:
#line 369 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempLocat_type) = (yystack_[1].value.autoTempLocat_type);  }
#line 961 "parser.cc" // lalr1.cc:847
    break;

  case 32:
#line 371 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempLocat_type) = (yystack_[0].value.autoTempLocat_type);  }
#line 967 "parser.cc" // lalr1.cc:847
    break;

  case 33:
#line 377 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempClock_type) = new autoTemp_Clock(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 976 "parser.cc" // lalr1.cc:847
    break;

  case 34:
#line 382 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempClock_type) = (yystack_[1].value.autoTempClock_type); }
#line 982 "parser.cc" // lalr1.cc:847
    break;

  case 35:
#line 384 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Clock* currClock = (yystack_[0].value.autoTempClock_type);
                autoTemp_Clock* nextClock = (yystack_[2].value.autoTempClock_type);
                (*currClock).next = nextClock;
	        	if(nextClock != NULL) (*nextClock).previous = currClock;
	        	(yylhs.value.autoTempClock_type) = currClock;
             }
#line 994 "parser.cc" // lalr1.cc:847
    break;

  case 36:
#line 392 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoTempClock_type) = (yystack_[0].value.autoTempClock_type); }
#line 1000 "parser.cc" // lalr1.cc:847
    break;

  case 37:
#line 394 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempClock_type) = NULL; }
#line 1006 "parser.cc" // lalr1.cc:847
    break;

  case 38:
#line 402 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempInvarExpr_type) = NULL; }
#line 1012 "parser.cc" // lalr1.cc:847
    break;

  case 39:
#line 404 "parser.yy" // lalr1.cc:847
    {
                autoTemp_InvarExpr* currInvExpr = (yystack_[0].value.autoTempInvarExpr_type);
                autoTemp_InvarExpr* nextInvExpr = (yystack_[2].value.autoTempInvarExpr_type);
                (*currInvExpr).next = nextInvExpr;
	        	if(nextInvExpr != NULL) (*nextInvExpr).previous = currInvExpr;
	        	(yylhs.value.autoTempInvarExpr_type) = currInvExpr;
             }
#line 1024 "parser.cc" // lalr1.cc:847
    break;

  case 40:
#line 412 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempInvarExpr_type)=(yystack_[0].value.autoTempInvarExpr_type); }
#line 1030 "parser.cc" // lalr1.cc:847
    break;

  case 41:
#line 416 "parser.yy" // lalr1.cc:847
    {

                 (yylhs.value.autoTempLocat2inv_type) = new autoTemp_Locat2inv(*(yystack_[4].value.stringVal), (yystack_[1].value.autoTempInvarExpr_type), NULL, NULL);
                 delete (yystack_[4].value.stringVal);               
             }
#line 1040 "parser.cc" // lalr1.cc:847
    break;

  case 42:
#line 423 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempLocat2inv_type) = NULL; }
#line 1046 "parser.cc" // lalr1.cc:847
    break;

  case 43:
#line 425 "parser.yy" // lalr1.cc:847
    {
                 autoTemp_Locat2inv* currLoc2inv = (yystack_[0].value.autoTempLocat2inv_type);
	         autoTemp_Locat2inv* nextLoc2inv = (yystack_[1].value.autoTempLocat2inv_type);		
	         (*currLoc2inv).next = nextLoc2inv;
	         if(nextLoc2inv != NULL) (*nextLoc2inv).previous = currLoc2inv;
	            (yylhs.value.autoTempLocat2inv_type) = currLoc2inv;
              }
#line 1058 "parser.cc" // lalr1.cc:847
    break;

  case 44:
#line 432 "parser.yy" // lalr1.cc:847
    {
                  (yylhs.value.autoTempLocat2inv_type)=(yystack_[0].value.autoTempLocat2inv_type);
               }
#line 1066 "parser.cc" // lalr1.cc:847
    break;

  case 45:
#line 440 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempLocalReset_type) = new autoTemp_LocalReset(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);    
	      }
#line 1075 "parser.cc" // lalr1.cc:847
    break;

  case 46:
#line 445 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempLocalReset_type) = NULL; }
#line 1081 "parser.cc" // lalr1.cc:847
    break;

  case 47:
#line 447 "parser.yy" // lalr1.cc:847
    {
                autoTemp_LocalReset* currReset = (yystack_[0].value.autoTempLocalReset_type);
                autoTemp_LocalReset* nextReset = (yystack_[2].value.autoTempLocalReset_type);
                (*currReset).next = nextReset;
	        	if(nextReset != NULL) (*nextReset).previous = currReset;
	        	(yylhs.value.autoTempLocalReset_type) = currReset;
             }
#line 1093 "parser.cc" // lalr1.cc:847
    break;

  case 48:
#line 455 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempLocalReset_type)=(yystack_[0].value.autoTempLocalReset_type); }
#line 1099 "parser.cc" // lalr1.cc:847
    break;

  case 49:
#line 458 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempLocalReset_type) = NULL; }
#line 1105 "parser.cc" // lalr1.cc:847
    break;

  case 50:
#line 460 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempLocalReset_type)=(yystack_[1].value.autoTempLocalReset_type); }
#line 1111 "parser.cc" // lalr1.cc:847
    break;

  case 51:
#line 464 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempGlobalReset_type) = new autoTemp_GlobalReset(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);    
	      }
#line 1120 "parser.cc" // lalr1.cc:847
    break;

  case 52:
#line 469 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempGlobalReset_type) = NULL; }
#line 1126 "parser.cc" // lalr1.cc:847
    break;

  case 53:
#line 471 "parser.yy" // lalr1.cc:847
    {
                autoTemp_GlobalReset* currReset = (yystack_[0].value.autoTempGlobalReset_type);
                autoTemp_GlobalReset* nextReset = (yystack_[2].value.autoTempGlobalReset_type);
                (*currReset).next = nextReset;
	        	if(nextReset != NULL) (*nextReset).previous = currReset;
	        	(yylhs.value.autoTempGlobalReset_type) = currReset;
             }
#line 1138 "parser.cc" // lalr1.cc:847
    break;

  case 54:
#line 479 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempGlobalReset_type)=(yystack_[0].value.autoTempGlobalReset_type); }
#line 1144 "parser.cc" // lalr1.cc:847
    break;

  case 55:
#line 482 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempGlobalReset_type) = NULL; }
#line 1150 "parser.cc" // lalr1.cc:847
    break;

  case 56:
#line 484 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempGlobalReset_type)=(yystack_[1].value.autoTempGlobalReset_type); }
#line 1156 "parser.cc" // lalr1.cc:847
    break;

  case 57:
#line 490 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempAssignment_type) = new autoTemp_Assignment(*(yystack_[2].value.stringVal), *(yystack_[0].value.stringVal), 0, NULL, NULL);
                 delete (yystack_[2].value.stringVal);  
                 delete (yystack_[0].value.stringVal);  
	      }
#line 1166 "parser.cc" // lalr1.cc:847
    break;

  case 58:
#line 496 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempAssignment_type) = new autoTemp_Assignment(*(yystack_[2].value.stringVal), *(yystack_[0].value.stringVal), 1, NULL, NULL);
                 delete (yystack_[2].value.stringVal);  
                 delete (yystack_[0].value.stringVal);  
	      }
#line 1176 "parser.cc" // lalr1.cc:847
    break;

  case 59:
#line 502 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAssignment_type) = NULL; }
#line 1182 "parser.cc" // lalr1.cc:847
    break;

  case 60:
#line 504 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Assignment* currAssignment = (yystack_[0].value.autoTempAssignment_type);
                autoTemp_Assignment* nextAssignemnt = (yystack_[2].value.autoTempAssignment_type);
                (*currAssignment).next = nextAssignemnt;
	        	if(nextAssignemnt != NULL) (*nextAssignemnt).previous = currAssignment;
	        	(yylhs.value.autoTempAssignment_type) = currAssignment;
             }
#line 1194 "parser.cc" // lalr1.cc:847
    break;

  case 61:
#line 512 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAssignment_type)=(yystack_[0].value.autoTempAssignment_type); }
#line 1200 "parser.cc" // lalr1.cc:847
    break;

  case 62:
#line 515 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAssignment_type) = NULL; }
#line 1206 "parser.cc" // lalr1.cc:847
    break;

  case 63:
#line 517 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAssignment_type)=(yystack_[1].value.autoTempAssignment_type); }
#line 1212 "parser.cc" // lalr1.cc:847
    break;

  case 64:
#line 522 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAction_type) = NULL; }
#line 1218 "parser.cc" // lalr1.cc:847
    break;

  case 65:
#line 524 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempAction_type) = (yystack_[2].value.autoTempAction_type); }
#line 1224 "parser.cc" // lalr1.cc:847
    break;

  case 66:
#line 529 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = NULL; }
#line 1230 "parser.cc" // lalr1.cc:847
    break;

  case 67:
#line 531 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = (yystack_[1].value.autoTempExpr_type); }
#line 1236 "parser.cc" // lalr1.cc:847
    break;

  case 68:
#line 533 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = NULL; }
#line 1242 "parser.cc" // lalr1.cc:847
    break;

  case 69:
#line 535 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = (yystack_[1].value.autoTempExpr_type); }
#line 1248 "parser.cc" // lalr1.cc:847
    break;

  case 70:
#line 538 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = NULL; }
#line 1254 "parser.cc" // lalr1.cc:847
    break;

  case 71:
#line 540 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempExpr_type) = (yystack_[1].value.autoTempExpr_type); }
#line 1260 "parser.cc" // lalr1.cc:847
    break;

  case 72:
#line 543 "parser.yy" // lalr1.cc:847
    {                 
                 (yylhs.value.autoTempTrans_type) = new autoTemp_Trans(*(yystack_[11].value.stringVal), (yystack_[9].value.autoTempAction_type), (yystack_[8].value.autoTempExpr_type), (yystack_[7].value.autoTempExpr_type), (yystack_[6].value.autoTempExpr_type), (yystack_[5].value.autoTempGlobalReset_type), (yystack_[4].value.autoTempLocalReset_type), (yystack_[3].value.autoTempAssignment_type), *(yystack_[1].value.stringVal), NULL, NULL);
                 delete (yystack_[11].value.stringVal);   
                 delete (yystack_[1].value.stringVal); 
            }
#line 1270 "parser.cc" // lalr1.cc:847
    break;

  case 73:
#line 549 "parser.yy" // lalr1.cc:847
    {
		   autoTemp_Trans* currTran = (yystack_[1].value.autoTempTrans_type);
	           autoTemp_Trans* nextTran = (yystack_[0].value.autoTempTrans_type);		
	     	   (*currTran).next = nextTran;
		       if(nextTran != NULL) (*nextTran).previous = currTran;
		       (yylhs.value.autoTempTrans_type) = currTran;
	      }
#line 1282 "parser.cc" // lalr1.cc:847
    break;

  case 74:
#line 557 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempTrans_type) = (yystack_[0].value.autoTempTrans_type); }
#line 1288 "parser.cc" // lalr1.cc:847
    break;

  case 75:
#line 559 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempTrans_type) = (yystack_[0].value.autoTempTrans_type); }
#line 1294 "parser.cc" // lalr1.cc:847
    break;

  case 76:
#line 566 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoTempBody_type) = new autoTemp_Body(*(yystack_[12].value.stringVal), (yystack_[10].value.autoTempParam_type), (yystack_[6].value.autoTempLocat_type), (yystack_[5].value.autoTempAction_type), (yystack_[4].value.autoTempInit_type), (yystack_[3].value.autoTempClock_type), (yystack_[2].value.autoTempLocat2inv_type), (yystack_[1].value.autoTempTrans_type), NULL, NULL);
                 delete (yystack_[12].value.stringVal);   
           }
#line 1303 "parser.cc" // lalr1.cc:847
    break;

  case 77:
#line 572 "parser.yy" // lalr1.cc:847
    {
                autoTemp_Body* currTemp = (yystack_[0].value.autoTempBody_type);
                autoTemp_Body* nextTemp = (yystack_[1].value.autoTempBody_type);
                (*currTemp).next = nextTemp;
	        	if(nextTemp != NULL) (*nextTemp).previous = currTemp;
	        	(yylhs.value.autoTempBody_type) = currTemp;
           }
#line 1315 "parser.cc" // lalr1.cc:847
    break;

  case 78:
#line 580 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoTempBody_type) = (yystack_[0].value.autoTempBody_type); }
#line 1321 "parser.cc" // lalr1.cc:847
    break;

  case 79:
#line 583 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.sharedClock_type) = new shared_Clocks(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 1330 "parser.cc" // lalr1.cc:847
    break;

  case 80:
#line 588 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedClock_type) = (yystack_[1].value.sharedClock_type); }
#line 1336 "parser.cc" // lalr1.cc:847
    break;

  case 81:
#line 590 "parser.yy" // lalr1.cc:847
    {
                shared_Clocks* currClock = (yystack_[0].value.sharedClock_type);
                shared_Clocks* nextClock = (yystack_[2].value.sharedClock_type);
                (*currClock).next = nextClock;
	        	if(nextClock != NULL) (*nextClock).previous = currClock;
	        	(yylhs.value.sharedClock_type) = currClock;
             }
#line 1348 "parser.cc" // lalr1.cc:847
    break;

  case 82:
#line 598 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.sharedClock_type) = (yystack_[0].value.sharedClock_type); }
#line 1354 "parser.cc" // lalr1.cc:847
    break;

  case 83:
#line 600 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedClock_type) = NULL; }
#line 1360 "parser.cc" // lalr1.cc:847
    break;

  case 84:
#line 603 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.sharedBool_type) = new shared_Bools(*(yystack_[0].value.stringVal), NULL, NULL);
                 delete (yystack_[0].value.stringVal);
             }
#line 1369 "parser.cc" // lalr1.cc:847
    break;

  case 85:
#line 608 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedBool_type) = (yystack_[1].value.sharedBool_type); }
#line 1375 "parser.cc" // lalr1.cc:847
    break;

  case 86:
#line 610 "parser.yy" // lalr1.cc:847
    {
                shared_Bools* currBool = (yystack_[0].value.sharedBool_type);
                shared_Bools* nextBool = (yystack_[2].value.sharedBool_type);
                (*currBool).next = nextBool;
	        	if(nextBool != NULL) (*nextBool).previous = currBool;
	        	(yylhs.value.sharedBool_type) = currBool;
             }
#line 1387 "parser.cc" // lalr1.cc:847
    break;

  case 87:
#line 618 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.sharedBool_type) = (yystack_[0].value.sharedBool_type); }
#line 1393 "parser.cc" // lalr1.cc:847
    break;

  case 88:
#line 620 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedBool_type) = NULL; }
#line 1399 "parser.cc" // lalr1.cc:847
    break;

  case 89:
#line 623 "parser.yy" // lalr1.cc:847
    {

                 (yylhs.value.sharedVar_type) = new shared_Vars(*(yystack_[6].value.stringVal), *(yystack_[5].value.stringVal), *(yystack_[1].value.stringVal), NULL, NULL);
                 delete (yystack_[5].value.stringVal);   
            }
#line 1409 "parser.cc" // lalr1.cc:847
    break;

  case 90:
#line 630 "parser.yy" // lalr1.cc:847
    {
                shared_Vars* currParametervar = (yystack_[0].value.sharedVar_type);
                shared_Vars* nextParametervar = (yystack_[1].value.sharedVar_type);
                (*currParametervar).next = nextParametervar;
	         	if(nextParametervar != NULL) (*nextParametervar).previous = currParametervar;
		       (yylhs.value.sharedVar_type) = currParametervar;
           }
#line 1421 "parser.cc" // lalr1.cc:847
    break;

  case 91:
#line 638 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedVar_type) = (yystack_[0].value.sharedVar_type); }
#line 1427 "parser.cc" // lalr1.cc:847
    break;

  case 92:
#line 640 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedVar_type) = NULL; }
#line 1433 "parser.cc" // lalr1.cc:847
    break;

  case 93:
#line 642 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedVar_type) = (yystack_[0].value.sharedVar_type); }
#line 1439 "parser.cc" // lalr1.cc:847
    break;

  case 94:
#line 644 "parser.yy" // lalr1.cc:847
    { (yylhs.value.sharedVar_type) = NULL; }
#line 1445 "parser.cc" // lalr1.cc:847
    break;

  case 95:
#line 646 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoProcParam_type) = new autoProc_Param(*(yystack_[0].value.stringVal), 1, "", "", NULL, NULL);
                 delete (yystack_[0].value.stringVal);   
            }
#line 1454 "parser.cc" // lalr1.cc:847
    break;

  case 96:
#line 651 "parser.yy" // lalr1.cc:847
    {

                 (yylhs.value.autoProcParam_type) = new autoProc_Param(*(yystack_[0].value.stringVal), 0, "", "", NULL, NULL);
                 delete (yystack_[0].value.stringVal);  
            }
#line 1464 "parser.cc" // lalr1.cc:847
    break;

  case 97:
#line 657 "parser.yy" // lalr1.cc:847
    {
                autoProc_Param* currParameter = (yystack_[0].value.autoProcParam_type);
                autoProc_Param* nextParameter = (yystack_[2].value.autoProcParam_type);
                (*currParameter).next = nextParameter;
	         	if(nextParameter != NULL) (*nextParameter).previous = currParameter;
	        	(yylhs.value.autoProcParam_type) = currParameter;
           }
#line 1476 "parser.cc" // lalr1.cc:847
    break;

  case 98:
#line 665 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoProcParam_type) = (yystack_[0].value.autoProcParam_type); }
#line 1482 "parser.cc" // lalr1.cc:847
    break;

  case 99:
#line 667 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoProcParam_type) = NULL;  }
#line 1488 "parser.cc" // lalr1.cc:847
    break;

  case 100:
#line 670 "parser.yy" // lalr1.cc:847
    {
                 (yylhs.value.autoProcBody_type) = new autoProc_Body(*(yystack_[6].value.stringVal),*(yystack_[4].value.stringVal), (yystack_[2].value.autoProcParam_type), NULL, NULL);
                 delete (yystack_[6].value.stringVal);  
           }
#line 1497 "parser.cc" // lalr1.cc:847
    break;

  case 101:
#line 675 "parser.yy" // lalr1.cc:847
    {
                autoProc_Body* currAutomaton = (yystack_[1].value.autoProcBody_type);
                autoProc_Body* nextAutomaton = (yystack_[0].value.autoProcBody_type);
                (*currAutomaton).next = nextAutomaton;
	         	if(nextAutomaton != NULL) (*nextAutomaton).previous = currAutomaton;
	        	(yylhs.value.autoProcBody_type) = currAutomaton;
           }
#line 1509 "parser.cc" // lalr1.cc:847
    break;

  case 102:
#line 683 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoProcBody_type) = (yystack_[0].value.autoProcBody_type);  }
#line 1515 "parser.cc" // lalr1.cc:847
    break;

  case 103:
#line 685 "parser.yy" // lalr1.cc:847
    { (yylhs.value.autoProcBody_type) = (yystack_[0].value.autoProcBody_type);  }
#line 1521 "parser.cc" // lalr1.cc:847
    break;

  case 104:
#line 687 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr(*(yystack_[2].value.stringVal),*(yystack_[0].value.stringVal), 1, NULL, NULL);
               delete (yystack_[2].value.stringVal);  
               delete (yystack_[0].value.stringVal);  
           }
#line 1532 "parser.cc" // lalr1.cc:847
    break;

  case 105:
#line 694 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr("",*(yystack_[0].value.stringVal), 2, NULL, NULL);
               delete (yystack_[0].value.stringVal);  
                
	   }
#line 1543 "parser.cc" // lalr1.cc:847
    break;

  case 106:
#line 701 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr("", *(yystack_[1].value.stringVal), 4, (yystack_[2].value.autoPropExpr_type), (yystack_[0].value.autoPropExpr_type));
               delete (yystack_[1].value.stringVal);  
                
	   }
#line 1554 "parser.cc" // lalr1.cc:847
    break;

  case 107:
#line 708 "parser.yy" // lalr1.cc:847
    {
                (yylhs.value.autoPropExpr_type) = &(*(yystack_[0].value.autoPropExpr_type)->setType(5));
           }
#line 1562 "parser.cc" // lalr1.cc:847
    break;

  case 108:
#line 712 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr("", *(yystack_[1].value.stringVal), 0, (yystack_[2].value.autoPropExpr_type), (yystack_[0].value.autoPropExpr_type));
               delete (yystack_[1].value.stringVal);             
	   }
#line 1572 "parser.cc" // lalr1.cc:847
    break;

  case 109:
#line 718 "parser.yy" // lalr1.cc:847
    {  (yylhs.value.autoPropExpr_type) = (yystack_[0].value.autoPropExpr_type);  }
#line 1578 "parser.cc" // lalr1.cc:847
    break;

  case 110:
#line 720 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr("", *(yystack_[1].value.stringVal), 0, (yystack_[2].value.autoPropExpr_type), (yystack_[0].value.autoPropExpr_type));
               delete (yystack_[1].value.stringVal);     
           }
#line 1588 "parser.cc" // lalr1.cc:847
    break;

  case 111:
#line 726 "parser.yy" // lalr1.cc:847
    {

               (yylhs.value.autoPropExpr_type) = new autoProp_Expr("", *(yystack_[1].value.stringVal), 3, NULL, (yystack_[0].value.autoPropExpr_type));
               delete (yystack_[1].value.stringVal);
           }
#line 1598 "parser.cc" // lalr1.cc:847
    break;

  case 112:
#line 732 "parser.yy" // lalr1.cc:847
    {

                (yylhs.value.autoPropExpr_type) = (yystack_[1].value.autoPropExpr_type);
           }
#line 1607 "parser.cc" // lalr1.cc:847
    break;

  case 113:
#line 737 "parser.yy" // lalr1.cc:847
    {
                (yylhs.value.autoPropExpr_type) = (yystack_[0].value.autoPropExpr_type);
           }
#line 1615 "parser.cc" // lalr1.cc:847
    break;

  case 114:
#line 741 "parser.yy" // lalr1.cc:847
    {

	          driver.net.autoTemps = (yystack_[9].value.autoTempBody_type);
              driver.net.sharedVars = (yystack_[6].value.sharedVar_type);
              driver.net.sharedClocks = (yystack_[5].value.sharedClock_type);
              driver.net.sharedBools = (yystack_[4].value.sharedBool_type);

	          driver.net.autoProcs = (yystack_[3].value.autoProcBody_type);
	          driver.net.autoProp = (yystack_[1].value.autoPropExpr_type);
	  }
#line 1630 "parser.cc" // lalr1.cc:847
    break;


#line 1634 "parser.cc" // lalr1.cc:847
            default:
              break;
            }
        }
      catch (const syntax_error& yyexc)
        {
          error (yyexc);
          YYERROR;
        }
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, yylhs);
    }
    goto yynewstate;

  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yyla.location, yysyntax_error_ (yystack_[0].state,
                                           yyempty ? yyempty_ : yyla.type_get ()));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyempty)
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyempty = true;
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if (false)
      goto yyerrorlab;
    yyerror_range[1].location = yystack_[yylen - 1].location;
    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;

  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yyterror_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yyterror_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yyerror_range[1].location = yystack_[0].location;
          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = yyn;
      yypush_ ("Shifting", error_token);
    }
    goto yynewstate;

    // Accept.
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    // Abort.
  yyabortlab:
    yyresult = 1;
    goto yyreturn;

  yyreturn:
    if (!yyempty)
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack"
                 << std::endl;
        // Do not try to display the values of the reclaimed symbols,
        // as their printer might throw an exception.
        if (!yyempty)
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
  }

  void
  Parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what());
  }

  // Generate an error message.
  std::string
  Parser::yysyntax_error_ (state_type yystate, symbol_number_type yytoken) const
  {
    std::string yyres;
    // Number of reported tokens (one for the "unexpected", one per
    // "expected").
    size_t yycount = 0;
    // Its maximum.
    enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
    // Arguments of yyformat.
    char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];

    /* There are many possibilities here to consider:
       - If this state is a consistent state with a default action, then
         the only way this function was invoked is if the default action
         is an error action.  In that case, don't check for expected
         tokens because there are none.
       - The only way there can be no lookahead present (in yytoken) is
         if this state is a consistent state with a default action.
         Thus, detecting the absence of a lookahead is sufficient to
         determine that there is no unexpected or expected token to
         report.  In that case, just report a simple "syntax error".
       - Don't assume there isn't a lookahead just because this state is
         a consistent state with a default action.  There might have
         been a previous inconsistent state, consistent state with a
         non-default action, or user semantic action that manipulated
         yyla.  (However, yyla is currently not documented for users.)
       - Of course, the expected token list depends on states to have
         correct lookahead information, and it depends on the parser not
         to perform extra reductions after fetching a lookahead from the
         scanner and before detecting a syntax error.  Thus, state
         merging (from LALR or IELR) and default reductions corrupt the
         expected token list.  However, the list is correct for
         canonical LR with one exception: it will still contain any
         token that will not be accepted due to an error action in a
         later state.
    */
    if (yytoken != yyempty_)
      {
        yyarg[yycount++] = yytname_[yytoken];
        int yyn = yypact_[yystate];
        if (!yy_pact_value_is_default_ (yyn))
          {
            /* Start YYX at -YYN if negative to avoid negative indexes in
               YYCHECK.  In other words, skip the first -YYN actions for
               this state because they are default actions.  */
            int yyxbegin = yyn < 0 ? -yyn : 0;
            // Stay within bounds of both yycheck and yytname.
            int yychecklim = yylast_ - yyn + 1;
            int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
            for (int yyx = yyxbegin; yyx < yyxend; ++yyx)
              if (yycheck_[yyx + yyn] == yyx && yyx != yyterror_
                  && !yy_table_value_is_error_ (yytable_[yyx + yyn]))
                {
                  if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                    {
                      yycount = 1;
                      break;
                    }
                  else
                    yyarg[yycount++] = yytname_[yyx];
                }
          }
      }

    char const* yyformat = YY_NULLPTR;
    switch (yycount)
      {
#define YYCASE_(N, S)                         \
        case N:                               \
          yyformat = S;                       \
        break
        YYCASE_(0, YY_("syntax error"));
        YYCASE_(1, YY_("syntax error, unexpected %s"));
        YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
        YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
        YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
        YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
      }

    // Argument number.
    size_t yyi = 0;
    for (char const* yyp = yyformat; *yyp; ++yyp)
      if (yyp[0] == '%' && yyp[1] == 's' && yyi < yycount)
        {
          yyres += yytnamerr_ (yyarg[yyi++]);
          ++yyp;
        }
      else
        yyres += *yyp;
    return yyres;
  }


  const signed char Parser::yypact_ninf_ = -122;

  const signed char Parser::yytable_ninf_ = -108;

  const short int
  Parser::yypact_[] =
  {
      67,    21,  -122,    60,    48,    82,    54,  -122,  -122,    64,
      90,    93,    95,     7,  -122,  -122,    30,    97,  -122,    95,
    -122,    65,  -122,    -3,    69,    93,    62,  -122,    70,  -122,
      68,   102,  -122,    -8,    99,  -122,    71,     7,    74,  -122,
     105,   107,   103,     5,    73,    14,     4,    77,   105,  -122,
    -122,     0,  -122,    78,    79,   101,   113,  -122,    22,   115,
    -122,    81,     0,     0,    50,    92,  -122,    19,    88,     5,
      86,    27,    94,  -122,    96,   120,    98,    26,   122,   124,
       0,  -122,     5,  -122,   100,  -122,   104,  -122,    -2,  -122,
       9,  -122,  -122,  -122,  -122,  -122,    98,   108,   125,   106,
    -122,   109,   127,  -122,    -4,  -122,  -122,  -122,    31,  -122,
    -122,   110,   112,    27,   111,  -122,   123,   129,    -1,   114,
       9,   125,  -122,    36,    43,   131,  -122,   116,     6,   121,
    -122,     6,   117,  -122,  -122,  -122,  -122,    38,   126,  -122,
     132,  -122,  -122,  -122,   134,   118,   128,  -122,    40,   138,
      87,  -122,   134,   130,   137,  -122,  -122,  -122,   125,    11,
     133,   135,  -122,    11,    11,   136,   139,  -122,   -11,    11,
     119,   140,   142,    37,    29,   145,    89,    11,  -122,   -10,
      11,   141,  -122,  -122,  -122,  -122,  -122,  -122,  -122,   142,
    -122,    15,   154,   144,  -122,  -122,  -122,    46,   155,   147,
    -122,   154,  -122,  -122,    47,   157,   143,  -122,  -122,   155,
     148,  -122,    51,   158,  -122,    91,  -122,   157,   146,  -122,
    -122,  -122,  -122
  };

  const unsigned char
  Parser::yydefact_[] =
  {
       0,     0,    78,     0,     0,     0,     0,    77,     1,     0,
      94,    16,    92,    83,    15,    18,     0,     0,    91,    93,
      79,     0,    82,    88,     0,     0,     0,    90,     0,    84,
       0,     0,    87,     0,     0,    17,     0,    83,     0,    81,
       0,     0,     0,     0,     0,     0,    88,     0,   102,   103,
      86,     0,    29,     0,    32,    27,     0,    80,     0,     0,
     101,     0,     0,     0,   109,     0,   113,     0,     0,     0,
       0,     0,     0,    85,     0,     0,   111,     0,     0,     0,
       0,   114,     0,    30,     0,    19,     0,    21,    37,    89,
      99,   104,   112,   106,   105,   108,   110,     0,    24,     0,
      33,     0,     0,    36,    42,    96,    95,    98,     0,    31,
      23,    26,     0,     0,     0,    20,    42,     0,     0,     0,
       0,    24,    28,     0,    37,    44,    35,     0,     0,     0,
      43,    74,     0,   100,    97,    25,    22,     0,     0,    75,
       0,    73,    76,    34,    38,     0,     0,    40,     0,    64,
       0,    41,     0,     0,    68,    14,    13,    39,    24,     0,
      66,     0,     4,     0,     0,     6,     0,    12,     0,     0,
      70,     0,     9,     0,     0,     0,     0,     0,    69,     0,
       0,    55,    65,     7,    11,     5,     2,     3,     8,    10,
      67,     0,    52,    49,    71,    51,    54,     0,    46,    62,
      56,     0,    45,    48,     0,    59,     0,    53,    50,     0,
       0,    61,     0,     0,    47,     0,    63,     0,     0,    57,
      58,    60,    72
  };

  const short int
  Parser::yypgoto_[] =
  {
    -122,  -122,   -33,   -20,  -122,  -119,    20,   149,  -122,    75,
      66,  -122,  -121,  -122,  -122,   -62,    56,    58,  -122,  -122,
      59,   -29,  -122,  -122,   -18,  -122,  -122,   -32,  -122,  -122,
    -122,  -122,  -122,  -122,  -122,   -51,   181,  -122,   156,   151,
     150,   152,   167,  -122,  -122,    72,  -122,  -122,   153,  -122,
     159,  -122,  -122,  -122,   -39,  -122
  };

  const short int
  Parser::yydefgoto_[] =
  {
      -1,   188,   165,   166,   167,   168,   147,    15,    16,    87,
      88,   111,   112,    71,    54,    55,   103,   104,   148,   130,
     118,   203,   204,   199,   196,   197,   193,   211,   212,   206,
     154,   170,   160,   181,   131,   132,     2,     3,    22,    23,
      32,    33,    18,    19,    13,   107,   108,    48,    49,    42,
      64,    95,    65,    66,    67,     4
  };

  const short int
  Parser::yytable_[] =
  {
     135,    29,   100,   127,    61,   116,    40,    83,    29,    52,
     101,    20,   105,   106,   128,   162,   177,   177,    53,    21,
      97,   128,    30,    76,    77,   178,   190,     5,    62,    30,
      41,    85,    63,   129,   117,    31,   102,   161,    86,   163,
     129,    96,   177,   164,   172,   174,    80,   100,     8,    57,
     179,   194,    31,    80,    81,   101,   177,    73,   189,    92,
      41,   191,   184,    24,   119,     1,   176,     6,    25,   120,
     183,   136,     1,   143,   102,   151,   117,   139,   152,  -107,
     141,    78,   200,   208,   201,   209,     9,   216,    10,   217,
     155,   156,   186,   187,   219,   220,    11,    14,    12,    17,
      26,    36,    28,    34,    37,    38,    20,    43,    46,    47,
      44,    29,    56,    51,    59,    68,    72,    69,    70,    74,
      75,    79,    82,    84,    91,    80,    61,    94,    90,   110,
      89,    85,   116,   100,    98,   127,   145,   140,   146,   180,
     113,    99,   185,   109,   173,   124,   114,   122,   121,   162,
     133,   169,   142,   138,   149,   153,   159,   150,   195,   202,
     144,   210,   218,   192,   158,   198,   213,   175,   176,   177,
     171,   205,   157,   126,    35,   125,   182,   115,   215,   123,
     214,   222,   137,   207,     7,   221,    27,    39,    45,     0,
       0,    50,   134,     0,     0,     0,     0,     0,    58,     0,
       0,    60,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    93
  };

  const short int
  Parser::yycheck_[] =
  {
     121,     4,     4,     4,     4,     9,    14,    69,     4,     4,
      12,     4,     3,     4,    15,     4,    27,    27,    13,    12,
      82,    15,    25,    62,    63,    36,    36,     6,    28,    25,
      38,     4,    32,    34,    38,    38,    38,   158,    11,    28,
      34,    80,    27,    32,   163,   164,    27,     4,     0,    35,
     169,    36,    38,    27,    35,    12,    27,    35,   177,    33,
      38,   180,    33,    33,    33,     5,    29,     7,    38,    38,
      33,    35,     5,    35,    38,    35,    38,   128,    38,    29,
     131,    31,    36,    36,    38,    38,     4,    36,    34,    38,
       3,     4,     3,     4,     3,     4,    32,     4,     8,     4,
       3,    39,    37,    34,    34,    37,     4,     8,    34,     4,
      39,     4,    39,    10,    37,    37,     3,    38,    17,     4,
      39,    29,    34,    37,     4,    27,     4,     3,    32,     4,
      36,     4,     9,     4,    34,     4,     4,    16,     4,    20,
      34,    37,   175,    35,   164,    34,    37,    35,    38,     4,
      36,    18,    35,    37,    36,    17,    19,    29,     4,     4,
      34,     4,     4,    22,    34,    21,    23,    31,    29,    27,
      35,    24,   152,   117,    25,   116,    36,   102,    30,   113,
     209,    35,   124,   201,     3,   217,    19,    31,    37,    -1,
      -1,    41,   120,    -1,    -1,    -1,    -1,    -1,    46,    -1,
      -1,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    78
  };

  const unsigned char
  Parser::yystos_[] =
  {
       0,     5,    76,    77,    95,     6,     7,    76,     0,     4,
      34,    32,     8,    84,     4,    47,    48,     4,    82,    83,
       4,    12,    78,    79,    33,    38,     3,    82,    37,     4,
      25,    38,    80,    81,    34,    47,    39,    34,    37,    78,
      14,    38,    89,     8,    39,    79,    34,     4,    87,    88,
      80,    10,     4,    13,    54,    55,    39,    35,    81,    37,
      88,     4,    28,    32,    90,    92,    93,    94,    37,    38,
      17,    53,     3,    35,     4,    39,    94,    94,    31,    29,
      27,    35,    34,    55,    37,     4,    11,    49,    50,    36,
      32,     4,    33,    90,     3,    91,    94,    55,    34,    37,
       4,    12,    38,    56,    57,     3,     4,    85,    86,    35,
       4,    51,    52,    34,    37,    49,     9,    38,    60,    33,
      38,    38,    35,    50,    34,    60,    56,     4,    15,    34,
      59,    74,    75,    36,    85,    52,    35,    57,    37,    75,
      16,    75,    35,    35,    34,     4,     4,    46,    58,    36,
      29,    35,    38,    17,    70,     3,     4,    46,    34,    19,
      72,    52,     4,    28,    32,    42,    43,    44,    45,    18,
      71,    35,    45,    43,    45,    31,    29,    27,    36,    45,
      20,    73,    36,    33,    33,    42,     3,     4,    41,    45,
      36,    45,    22,    66,    36,     4,    64,    65,    21,    63,
      36,    38,     4,    61,    62,    24,    69,    64,    36,    38,
       4,    67,    68,    23,    61,    30,    36,    38,     4,     3,
       4,    67,    35
  };

  const unsigned char
  Parser::yyr1_[] =
  {
       0,    40,    41,    41,    42,    43,    43,    43,    44,    45,
      45,    45,    45,    46,    46,    47,    48,    48,    48,    49,
      50,    50,    50,    51,    52,    52,    52,    53,    53,    54,
      55,    55,    55,    56,    57,    57,    57,    57,    58,    58,
      58,    59,    60,    60,    60,    61,    62,    62,    62,    63,
      63,    64,    65,    65,    65,    66,    66,    67,    67,    68,
      68,    68,    69,    69,    70,    70,    71,    71,    72,    72,
      73,    73,    74,    75,    75,    75,    76,    77,    77,    78,
      79,    79,    79,    79,    80,    81,    81,    81,    81,    82,
      83,    83,    83,    84,    84,    85,    85,    86,    86,    86,
      87,    88,    88,    89,    90,    91,    92,    92,    93,    93,
      94,    94,    94,    94,    95
  };

  const unsigned char
  Parser::yyr2_[] =
  {
       0,     2,     1,     1,     1,     3,     1,     3,     3,     2,
       3,     3,     1,     3,     3,     1,     0,     3,     1,     1,
       3,     1,     5,     1,     0,     3,     1,     0,     5,     1,
       3,     5,     1,     1,     5,     3,     1,     0,     0,     3,
       1,     5,     0,     2,     2,     1,     0,     3,     1,     0,
       3,     1,     0,     3,     1,     0,     3,     3,     3,     0,
       3,     1,     0,     3,     0,     5,     0,     3,     0,     3,
       0,     3,    14,     2,     1,     2,    15,     2,     1,     1,
       5,     3,     1,     0,     1,     5,     3,     1,     0,     7,
       2,     1,     0,     2,     0,     1,     1,     3,     1,     0,
       7,     2,     1,     2,     3,     1,     3,     1,     3,     1,
       3,     2,     3,     1,    10
  };



  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const Parser::yytname_[] =
  {
  "\"end of file\"", "error", "$undefined", "INTEGER", "IDENT", "MODULE",
  "PROCESS", "NETSYSTEMS", "VAR", "INVS", "INVARSPEC", "INIT", "CLOCK",
  "LOCATION", "PRO", "TRANS", "FROM", "ACTION", "LOCAL_GUARD",
  "GLOBAL_GUARD", "VAR_GUARD", "LOCAL_RESET", "GLOBAL_RESET", "GOTO",
  "VAR_ASSIGNMENT", "BOOL", "LOGVAL", "OPERATOR", "NEG", "RELATION",
  "ASSIGMENT", "MINUS", "LPAREN", "RPAREN", "LCURLY", "RCURLY",
  "SEMICOLON", "COLON", "COMMA", "DOT", "$accept", "constant", "variable",
  "term", "atomexpr", "expr", "autoTempInvExpr", "autoTempParam",
  "autoTempParams", "autoTempInit", "autoTempInits", "autoTempAction",
  "autoTempActions", "autoTempActionsDec", "autoTempLocat",
  "autoTempLocats", "autoTempClock", "autoTempClocks", "autoTempInvExprs",
  "autoTempLocat2inv", "autoTempLocat2invs", "autoTempLocalReset",
  "autoTempLocalResets", "autoTempLocalResetDec", "autoTempGlobalReset",
  "autoTempGlobalResets", "autoTempGlobalResetDec", "autoTempAssignment",
  "autoTempAssignments", "autoTempAssignmentDec", "actionExpr",
  "localguardExpr", "globalguardExpr", "varguardExpr", "autoTempTran",
  "autoTempTrans", "autoTemp", "autoTemps", "sharedClock", "sharedClocks",
  "sharedBool", "sharedBools", "sharedVar", "sharedVars", "sharedvardec",
  "autoProcParam", "autoProcParams", "autoProcess", "autoProcesss",
  "Processsdec", "propertyvar", "propertyconstant", "propertyterm",
  "propertyatom", "property", "start", YY_NULLPTR
  };

#if YYDEBUG
  const unsigned short int
  Parser::yyrline_[] =
  {
       0,   216,   216,   221,   227,   233,   239,   244,   247,   254,
     259,   264,   266,   268,   276,   285,   292,   293,   303,   310,
     316,   324,   326,   331,   337,   338,   346,   349,   350,   355,
     360,   368,   370,   376,   381,   383,   391,   394,   402,   403,
     411,   415,   423,   424,   431,   439,   445,   446,   454,   458,
     459,   463,   469,   470,   478,   482,   483,   489,   495,   502,
     503,   511,   515,   516,   522,   523,   529,   530,   533,   534,
     538,   539,   542,   548,   556,   558,   563,   571,   579,   582,
     587,   589,   597,   600,   602,   607,   609,   617,   620,   622,
     629,   637,   640,   641,   644,   645,   650,   656,   664,   667,
     669,   674,   682,   684,   686,   693,   700,   707,   711,   717,
     719,   725,   731,   736,   740
  };

  // Print the state stack on the debug stream.
  void
  Parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << i->state;
    *yycdebug_ << std::endl;
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  Parser::yy_reduce_print_ (int yyrule)
  {
    unsigned int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):" << std::endl;
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG

  // Symbol number corresponding to token number t.
  inline
  Parser::token_number_type
  Parser::yytranslate_ (int t)
  {
    static
    const token_number_type
    translate_table[] =
    {
     0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39
    };
    const unsigned int user_token_number_max_ = 294;
    const token_number_type undef_token_ = 2;

    if (static_cast<int>(t) <= yyeof_)
      return yyeof_;
    else if (static_cast<unsigned int> (t) <= user_token_number_max_)
      return translate_table[t];
    else
      return undef_token_;
  }


} // example
#line 2221 "parser.cc" // lalr1.cc:1155
#line 756 "parser.yy" // lalr1.cc:1156
 /*** Additional Code ***/

void example::Parser::error(const Parser::location_type& l,
			    const std::string& m)
{
    driver.error(l, m);
}
