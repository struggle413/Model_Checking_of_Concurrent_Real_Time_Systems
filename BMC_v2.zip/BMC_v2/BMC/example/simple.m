MODULE Process Fischer()
{
    VAR 
        Location : {l0, l1, l2}

        Init:{l0}
        Clock: {x} 
    INVS
        l0 : {x <= 6}
        l1 : {x <= 5}
    TRANS
        {FROM l0; CLOCK_GUARD x=1; GOTO l1}
        {FROM l1; CLOCK_GUARD x>3; GOTO l0}
        {FROM l1; CLOCK_GUARD x>=5; RESET x:=0; GOTO l2}
}

NETSYSTEMS
{

    PRO
        p1:Fischer();


    INVARSPEC  
        p1.l2
}


























